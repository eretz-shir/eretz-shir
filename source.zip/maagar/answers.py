# Answers from the review page (k|pid|title|answer|note)
ANSWERS = """
A|jlm_ammo|גבעת התחמושת|ok|
A|jlm_ramatrachel|שובי בת ירושלים|ok|
A|jlm|אור וירושלים|ok|
A|road_to_jlm|הנה אני בא|ok|
A|valley90|האיש מן הבקעה|ok|
B|betlehem|ראי רחל ראי|M|
B|efrat|בשדמות בית לחם|A|
B|jericho|עץ הרימון|M|
B|jlm|אם אשכחך ציון תמתי|W|
B|jlm|ציון, ציון תמתי|A|
B|kinneret|היו לילות|M|
B|kochav|שיר על שושנה|A|
B|tiberias|לצפון באהבה|note|לא קשור ספציפית לשם
B|tiberias|שירי לי כינרת|A|
B|tiberias|שם הרי גולן|A|
B|trumot|שיר על רעי|A|
B|tzemach|ביתי אל מול גולן|W|
B|tzemach|הכל פתוח|A|
"""
