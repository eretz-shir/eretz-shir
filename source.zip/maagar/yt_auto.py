# YouTube links from automatic search 04.11 (SA=Shir Ad exact title, P=title+performer, L=title match). All need review.
YT_AUTO = """
אני זוכר את בית הערבה|PEoYg2vpgVE|
אומרים ישנה ארץ|RSbttglpM6I|
סימן שעוד לא הגענו|p320GUpKgkQ|
ארץ טרופית יפה|67DR0OvgbGA|
יושב מול הנייר|pea_xZflHVY|
אלול בעין כרם|sEazRcSfHbg|
על חומותייך ירושלים|vJSqwQCXggg|
שובי בת ירושלים|a07nqk9PB0c|
שער הרחמים|9vweQZfJKBo|
הר הגלבוע|GlML-ldPNV8|
שירת דבורה|aX7O0NiVUJc|
חצץ, על הסלע הך|EWHxpFNhuEo|
אור ירד על שדותינו|AFK8-EZCN1g|
בדרך מבית אלפא|msvuIYDdvT0|
שורו הביטו וראו|I3XA_5QhXY0|
ים השיבולים|OHxXw7MmQm4|
שיירה שלנו|QdS43ceBn5k|
בת שישים|OryIjEt9Ftg|
אנחנו שנינו מאותו הכפר|aqQUJpwXKnc|
העמק הוא חלום|cFw-FmM-rqo|
עפולה|i9JyuRNtstk|
אנו נהיה הראשונים|K52uImcaMhI|
על הגורן בליל לבנה|AY9rxZZwPoE|
אל יבנה הגליל|4coJA6vHe8U|
ערב במסחה|dLSo5omzrsY|
ידיד נפש|ISMl0FucQJI|
בר יוחאי|RXk2J9M0f58|
אסתר|Mk32-OPPGEM|
עוד לא אהבתי די|V4QSoLFj-NM|
דודו|oEcK9D7Fgw8|
דוד|bYKK46GRme4|
משמר הירדן|Nkp7aa4C0Mw|
האם את בוכה או צוחקת|qt15Ovonlr0|
קריית שמונה|r0oMtoVoaC0|
הלילות בכנען|mHwhc8qtt_E|
מטולה|jfZ9vHVbR7o|
תל אל קאדי|6XiViyZ36q8|
עד לתל פאחר|h0Qwxk4zPCM|
מלכות החרמון|9i2_5ElRkuY|
לילה בחוף אכזיב|MFrjlagc8rE|
רכבת העמק|0zGm5amCVYk|
שיר הקברניט|mwRtehKUkFo|
שמעו שמעו|35IM4jLM8Y4|
נוף ילדות|OER8dtQPF14|
ימי בנימינה|KxzgoRcUSdM|
פרדס חנה בשבת|vT75AVNd-sY|
בלוז כנעני|kCR7tO3WoIQ|
פרדס חנה|CQG33CFPJ3c|
אגדת דשא|CwAAXWfyBqQ|
מה אברך|b8o9r07sYgA|
הנמל|Izkkc-cnlV8|
אין כמו יפו בלילות|HoRsR0eQI2o|
חלון לים התיכון|wtUpKtrDG-I|
מצב רוח יפואי|xTRxhGCFJwA|
נמה יפו|WEhlEEvCPLA|
פה ביפו|kyVJNFigAWg|
טאנגו כפר סבא|-uivogddoB4|
הבלדה על יואל משה סלומון|VBaahU8YmyA|
בני ברק|Eq8pAOAEIqA|
נולדתי בראש העין|npzmgmjmU4o|
האח ראשון לציון|0CAEr4uRVXE|
יקבי ראשון לציון|OepLMZhzR5U|
האורכסטרה של ראשון לציון|TTUX3yMoCCU|
רחובות שלי|s6b7_9pVyOM|
המנון לרחובות|oOrNNIzNqjs|
כי תבוא אל מודיעין|fgM4jUH6Swc|
שושנה|z9KNROLeB_w|
אחותי רוחמה|DJFWTrj5sO8|
ארץ מלח|jaVXIZVeqaA|
ים המלח|TaSvsjcZN9g|
מי הרג את ים המוות|9J8GpSRGduc|
המקום הכי נמוך בעולם|XrgsMtGGey0|
מצדה|bXutOtlpfPw|
הדרך לערד|4E4kePWquf4|
בצהרי יום|A4QpkNRY-Mo|
זכריה בן עזרא|KNTSrTSyfrc|
שיר שמח|p_auZ_V0edI|
אל הגבים|sHrw7T5_btA|
הדרך לאילת|_Oy_vcmT9lw|
היורד דרומה|Xns7M8nVGvg|
מחול יטבתה|BiqmfoW3wqw|
סתם יום של חול|d0S3ImXYUpg|
אגדת באר אורה|4RJF3xhTNss|
בואי לאילת|-s7B10ceWyo|
לאילת|0a_aItNGHdY|
עיר מקלט|rwT_arV6oIs|
ספני שלמה המלך|3iQEC7mO3YY|
אין לי ארץ אחרת|MEJ5jgCaDhE|
אנחנו שרים לך|lQnp2XI_MB4|
בארץ אהבתי השקד פורח|jyRvyedGGPk|
בארץ הזאת|fJeDPqkM_IA|
בואו נשיר לארץ יפה|7RKawSd0UYo|
הוי ארצי מולדתי|-FjCXCRBNDw|
השיר על הארץ|ICILopmFjzE|
פה בארץ חמדת אבות|FV8VrPycFos|
תוצרת הארץ|X6rsfFU6J1o|
שלום לך ארץ נהדרת|DgvmC-F5jsE|
טוב ללכת בדרכים|MDarBkxXkGM|
הטיול הקטן|dDXngW-5jV0|
דרך ישנה|T92utGDZYZI|
סימני דרך|gsw1z4xANfs|
עוד נגיע|acVtcvrrt54|
בין גבעות הרי אפרים|bvCGBF5gEt8|
המנון משמר השרון|Dl5jgRJl_Ig|
הורה משמרות|5KjYm74U8jk|
אשקלון|1SxUrAjUK7Y|
בערבות לכיש|mzqHnfhxUoA|
אצל כותל מערבי|pSPYH0ucfpA|
ובעיר ירושלים|2Kb5cx6KmAc|
ירושלים|3TGF1-tC_t8|
קומי ירושלים|FOKKo603D7U|
בכרם תימן|0L5dklFges0|
תל אביביה ב'|_Wb43Zef5Q0|
על גבעות שיח' אבריק|7ktj4dMxL-I|
טיילתי בעמק|rANhu-KKAUo|
עמק|yhc1iOcQLg4|
דבקה גלבוע|gWPDMLnMah8|
הורה עמק הירדן|Iiy5xpxvP74|
אני מאיילת אשר בגליל|SPqt7VvHdyE|
תל-חי|BNyfSkKfH-s|
חיילי הגליל|zNbB7APT4EQ|
יוסף הגלילי|rspvCZlnpaY|
כל בחורי הגליל|Z32wznGH9D8|
שיר הגליל|qrUDut-2W1Y|
שירת הגליל|h_mPExxf7bI|
שיר הנגב|hxIVgBQNgGg|
בגבולות המדבר|Z6sah551GU8|
את אדמה בלב מדבר|ljmiojhVhAg|
מדן ועד באר שבע|mnlAYGZLGss|
אורחת גמלים|wySINDnhlZk|
אנחנו נשארים בארץ|yDD0sEMrjsg|
ארץ הצבר|AYEVjMFURC4|
ארץ ישראל|Icoda51JrN4|
יליד הארץ|UqIY_YtEpOA|
בוא איתי אל הגליל|_8jPCgHSEL8|
כוכב הצפון|eADf89FhnNM|
חורף באילת|2FXcmz5sLT0|
כולם באילת|BwRbvR3MtXc|
אשדודית באליטה|pwd5y3xFCzw|
שיר הקטר|xZ3HW9JYcmU|
מבת ים ועד הנצח|OudsUfjWbcM|
ירושלים שלי|sCdu0jArPUA|
ציון הלא תשאלי|hWw-t6B0SOo|
אלי ציון ועריה|w1_8fMwQNIY|
פתח תקווה (אינפקציה)|SRgXVQkl_2M|
מערב ראשון|Rpn5s235RTk|
גשר אלנבי|huSs_UM8oLo|
אל הכפר|c43WeAW2m7M|
אלי חופי אדמת מולדת|Np4SsFNLcog|
אם נשוב|U77LDGjQBeg|
אנו עולים ושרים|FHb3Ao5bZqY|
באלפי ידיים|wLlCjQcNSEU|
הו ארץ מולדת|GG4TFEDaVkM|
הוי ערש מולדת|hQuWk6aeJNY|
הורה סחרחורת|88jbQhNHpIE|
השושנה|wlwrb-h4ir4|
ישראל את חיינו|z-CV18PctBE|
למולדתי|XIfwh0ZvtAk|
מכורתי|XrlQeIBZ7kU|
מלאו אסמינו בר|KxfOK38Qqs4|
קטונו מאוד|_wELFk03SxI|
רוני אדמת מולדת|8dvJYhSNFiA|
שאו ציונה נס ודגל|yzTTEhtOBKw|
שירת השומר|6lMuPfm8DwQ|
כי בא האות|VSNEhFWq9kA|
אמא אדמה|t3e90x9mLrs|
ארץ שבעת המינים|BKw0wxWTqn8|
גוונים|_scqR_X70bY|
הזורעים בדמעה|MiAMNr9Ucvg|
והטיפו ההרים עסיס|H-It-MhZI0Y|
חג אסיף|hpbWD6HaD8Y|
שדמתי|EPqmvexXniQ|
שיר הבוצרים|ywmjbu34wZk|
שירת הקציר|7Y2biHYBiRQ|
שיר השדה|-SoJTuTSVQ4|
שיר חקלאי|4bLusQtjeBc|
אנו באנו ארצה|35oX3mKZ5yI|
שירו נא המשוררים|it7iiQVg7KY|
גבעה אחת|-xQjPNLbj2U|
דרך הכורכר|KlB8Wecz_aM|
הביתה|bTu1iVqnOTU|
טיול לילי|UXrTQWCK5Zk|
לחזור הביתה|oZ05DVEE1JE|
שיר ללא שם|doh10LVsJYA|
שיר בבוקר בבוקר|Big-1vigRM0|
אם אתה בסביבה|X-eQOTWiXaU|
שיר עולה|vaSyOb9jY1M|
שיר השיירה|qElqp7mNc8g|
שיר ארץ|Buj6hu6zsdI|
בלדה לעוזב קיבוץ|HjQhVTTC6_4|
בדרך הגדולה, ענבלים|_lXMt89V2sI|
על העיר עפות יונים|W6_32lFHna4|
ערב עירוני|gAOtYllvULg|
איל|ZH5PyneEPk4|
בוקר טוב גלבוע|mePKECBJrzE|
שיר החייל|r10sDUpGm7s|
בית הערבה|7f1K2GwLZbA|
במדרון היורד מגבע|6wQ6_z1FcG0|
הודי חמודי|ocrSDChUC7g|
טוב לי בקיבוץ|YFE524L9bFA|
יוחנן וגבריאל|0Jl647CkkUs|
ילד השדה|kACF8CKfh80|
ליל קציר|oTWqBTdK5jA|
לילה בבית הילדים|nYVVNcJ5IvM|
סרנדה לעדה|8OPhSPMVpUw|
שיר העמק (באה מנוחה ליגע)|jPLZTOfhk8w|
אתם זוכרים את השירים|ssOp8d532B0|
האסי שלנו|ekvAQx6TP74|
עורו אחים ונעלה|EvWoawwxpoo|
בית אלפא ביתי|K6xnbgDyJLY|
גבעת האהבה|716IzVCPWCU|
יוצא לאור|0hgfLoI-UDA|
שיר היונה|C6s2rW-GMTo|
בן גוריון (גרוניך)|JnUrS5aWb5U|
האיש ההוא|TEK04z4t240|
אליעזר בן-יהודה|Jt2gLGvLKW0|
רחל|bXWvJgh-20o|
זמר לגדעון|ofjbGMH1zd0|
עורי דבורה|87epH0nWmWM|
לנשמת הרצל|B0OHwe0tTxo|
דוד מלך ישראל|UFBQKZSqzuc|
הכה שאול באלפיו|3v1LG7OqJEU|
בנימין זאב|f39Xb3Is_5M|
יהודה המכבי|tAfOfYj1KZ4|
אליהו הנביא|6Hl3Saxjzo4|
אסיף (אסוף את המעשים)|SallVX4DCuc|
אם יש אלוהים|87GOsmdTB4M|
טל חרמון|fk4To_2AeCY|
חברון שלי|B-V9uOlcuj8|
רבנו גורן|mS82rGTsXNQ|
כרמיאל|oTLNaMVQwAY|
כרמיאל רוקדת|iQv05VmhFqU|
בכל שנה בסתיו גיורא|YgYyQjI4UeY|
טיול בגליל|hkP68rzytgU|
הרצליה|_4zfPh-PGcQ|
מצפה רמון|8pWbj7Fe6As|
האזרח הקטן משדרות|pJldrDzSnnM|
כביש הערבה|YOriCJcYfX0|
ארץ ערבה|d9-CSY1V4R0|
הזולה בעמק החולה|7XL7WqJhx24|
חלום יעקב|q60KK6xEqXA|
בחום הלב חברון|B2mW3F_eGxo|
אלנבי חברון|8Qm5_nhu4t4|
איפה הם כל אבותינו|i73iuCjtfpA|
עמק דותן|c-yvk1G7XP0|
נקודה טובה|WGD-vevNm-c|
שומרון|N2ERG62Z0JM|
שער השמים|pwlM_KyB6EI|
אמצע הלילה בכפר|BkjnadCaosk|
זה היה ביתי|YNl-bjj80Ho|
דבקה רפיח|j-fjA55j7_g|
מלכה קמה|j1HizAi4HW4|
עקרה (בן לו היה לי)|Va7E6mW-7Yc|
סלינו על כתפינו|7mJene6zNOA|
גן יבנה|Rbg3qWraYNA|
כשנפוליאון יכבוש את עכו|uAX-FrSU3KE|
הנה מוטלות גופותינו|WEdizTEdBCs|
שועלי שמשון|1ciy5dMajxI|
גוליית|B0xWYu3zasE|
שני אלונים|Os39OhiEEjg|
קסם כלנית לעד|Zx_Z5vHaATo|
שמש בגבעון דום|6kwCO6uCK3s|
מקום|wohwDTTOn5A|
טרמינל|rANiul86eSU|
אור בהירות הדרך|ZZPTEZl3n8M|
כמו רקפות|U5fvtgXPQs0|
כלת מלך|yq7gkI-gYGI|
ארץ הקדושה|6iOr6QrujSs|
שיר הגשר|wB6bX3bMU50|
שכב בני|jOaSWpzYDTI|
בין גבולות|ttg9cMbKAKc|
ברית דמים|sL-0pzlbpqw|
הנני כאן|ijPL6Yi8VRM|
בלדה לשוטר|L2EACh2FzM8|
חושו אחים חושו|anA4PQG7AKs|
מסע לילי|pDVB3gTtpTQ|
צל עץ תמר|vdzysWujnhI|
שיבולת בשדה|9BO8KQnNxQQ|
אל השדות|s632TVO3x8s|
נצא השדה|vAT50nuKMh8|
שוטי ספינתי|YqdoOQm1mxc|
אנשי הגשם|Jton2Sg5ZY8|
מגדל העמק|AGFoqvKfDos|
גולני שלי|LRN6QrVuR3E|
יעל|T1OktKbUVkc|
אם סיסרא|yMTuuutvNtA|
שיר הכדוריסטים|pZd5KORoU4U|
מול הר סיני|WKNC9cliAL4|
בהיאחזות הנח"ל בסיני|4mnHj2UM1uM|
גדודו של חיים|g2h6REMoBLA|
הורה מגפיים|biacj49v2_c|
נבנה ארצנו|vDwTfhR8OW4|
הקרב האחרון|CV9J2PBmZu8|
שב אל אדמתי|_a0Kr5VYAbU|
אם אשכח ירושלים|JqPyJEmG4V8|לירן דנינו
שומר חומות|pS2rl8q3epg|להקת פיקוד מרכז
לא אורחת גמלים|rSZ5ZD5PcdE|הגבעטרון
שיר געגועים לכפר סבא|6XmIOcpuyxQ|חבורת שהם
רחובות את ביהודה|NekMx_Qr9Pw|
המנון לפתיחת האוניברסיטה העברית|di0qxjCsclI|
לילות תל אביב|ArnNnppL0m8|דפנה דקל
לשדות יזרעאל|ZtNDS3kotbw|
זמר קטן מן העמק|ihMFGlnWCjE|נורה משולם
זרום ירדן זרום|xhkCpepxR1k|
אם כינרת|JF2Rt0NRJTc|הדודאים
מרים מנהריה|0aFfXTeC6eE|
נעורים לערבה|kWUrtxYTrW0|
שתילים במדבר באר שבע|aNwTmdpBwYY|
נגב שלנו|p20GLszvKLw|
אל ארץ טובה|WSyiMPcMbvs|להקת גלגל
אנו עלייך שומרים|KdOuOlu89r0|
הרוח שוטטה|CUMLg2e1J-U|
אהבת איילת|Mve7AI-sa6E|
בלדה לחרוב|2pUlqLLQ7SA|
כביש 5|PKngEILnMJU|אריאל זילבר
בלדה על החיים החיצוניים|gnmy6w_tRnE|שלמה ארצי
לא סיפרתי לך על עכו|ND1fVr1UhSg|רפאל בן נון
סע לאט (א)|ZwTbFd8kdII|אריק איינשטיין
שיר בית"ר (המנון בית"ר)|d4qyI8kPvik|
ארץ אהובה (אביהו מדינה)|J-QJvncrGcQ|אביהו מדינה
"""
