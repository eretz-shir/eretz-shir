# From the "שיר עד" YouTube playlist (songs of places and landscapes) and Hebrew Wikipedia categories.
# YT_LINKS: title|videoId — used to fill YouTube links for songs already in the table (matched by title)
YT_LINKS = """
בדרך לאילת|4S_obOhIh4o
היי דרומה|4S_obOhIh4o
בהר הגלבוע|BzsgDIk1_J0
אם הדרך נמשכת|uwJ3AgRrZSY
בדאלית אל כרמל|isGcuiCFD-A
בדלית אל כרמל|isGcuiCFD-A
זמר של טיול|1K-W4nMymQI
עמק עמק עבודה|HZ__RkCAWOY
בחורשה על גבעות השומרון|QeAj5jF84kw
חג הביכורים בעמק|BJ5xpp-VqLQ
הכותל|xAvWYU2vrcY
ביהודה ובגליל|tsKQ2hO5Ixw
על ראש החרמון|z_oeSw6TZPw
שיר בוקר|BHfP16n-ClA
זו אילת|FGjyX76nNeM
אגדת הירדן|9Z107-sShVE
הירדן|kgqVeMHmHlQ
אל החולה|7D7qWAKWfws
נס ציונה|jB9Ji963-xs
סימונה מדימונה|eOjH2xcaAPk
ירושלים של מטה ומעלה|1gs55VBbIe4
יפו|6j4Xtlrhvzg
גילו הגלילים|uc1fF0UBLLM
מי יבנה בית|yUOurlUP9sE
יפה נוף|XBDLA4KanR0
שי|iSyoq6dcqDE
הורה נען|XPBZK8l_xbM
הוי ארצי הורתי|SyPKqQIVR5Q
ישושום מדבר וציה|EpLKlkGJm8o
ירדה השבת|BqYlcVFDMP4
שיר העמק|fOrR14KWKDs
הרעות|ylb0BkafCRQ
באב אל וואד|Jqsmy_ZQ7II
מרגלות הכרמל|2-GgiQZsKmU
ארץ ישראל יפה|nU7Fx5qtUWE
תל אביב שלי|Qbo_8hAqIjk
אל הנגב|HVkBf6xiUAM
מי בונה ירושלים|1JV3Y46TDSQ
בעמק בית שאן|SKzYhYuusrY
בדרך לתבור|Fmf8z3BaC68
שירת הנודד|D2HPYGZIHmY
שיר ההודיה|afGspbn3zEQ
הבו לבנים|6TfbmlrLQsY
הטנדר נוסע|Evv8plvtI9g
הסבתא בנגב|wEIyTG0DPm4
בערבות הנגב|2uArIgTTY_A
שיר המזג|DB77OStF9Jc
ויבן עוזיהו|ETGHzBI6Ebo
הביא לי הרוח, מראש הכרמל|96VO-mWym0E
שירת העמק|dFqffMlkj2k
חורשת האקליפטוס|l4GFzyuGRC4
אדמה אדמתי, על גבעת שייך אברך|NjSG7Umbg0E
מעל פסגת הר הצופים|T52ZKmEMYN4
הרועה בגליל|5OBlCe4GrwE
קציר בעמק|fgLdsj78UeA
עורי ציון|-
משלט עזוב|jbcsNioxmM8
שיר ערש נגבי|dnvg_Ln6g8A
זוהי יפו|CJRa33bUbDM
למדבר|QrI0fzNiJ8I
הליכה לקיסריה|H2SeYpGnUUQ
האיש ההוא|TEK04z4t240
ארץ זבת חלב ודבש|Fbn2H7849Y8
שיר הבוקרים|T03rfcAsl6o
למדבר שאנו|My6tKUST4To
לשיר זה כמו להיות ירדן|1RcTpcL_X4k
אורחה במדבר|fyXzTvXdAck
ערב בגליל|Ry1aTw6qNrk
היו לילות|MK3oKhUKP4g
זמר, לילה בגלבוע|hlTTT0K1krE
את אדמה|OBYzJU2eYxc
עץ הרימון|KyWpF3CQwdA
ערב מול גלעד|iNXSLdQjChg
העיר הלבנה|AVcJxgfWBzo
הגלילה|UruIRs4YL_8
בשדמות בית לחם|6Pk0AURpGKI
אגדה על שפת ים כנרת|CdG5ibtvNJI
ירושלים של זהב|DkNditzB6YI
שם הרי גולן|4TjSg5Qa0Ys
שוב הגעתי לכינרת|UK0w7alzUxI
בגליל בתל חי|ghOVt8WEj1U
עלי גבעה|eF8EJWeFD5M
הוא לא ידע את שמה|IpDRB7Y6Wgc
סבא חרמון|h6yzpinZgGA
ואולי|kKgWCxHHYdU
אל ארצי|cU6EuRWTn1c
חלוץ שכמוני|D0rWZJybQgU
שיר הנמל|JIWtZA7FpIc
מכרות שלמה|rVQfKh9-Zy0
תל קציר|pW_V4_t361M
אם אשכחך ציון תמתי|PbOoMqJ2yxM
אם אשכחך ירושלים|Rh1fhmpygv0
ראש פינה|vH6LxgJErd4
הולכים בלילה|U5uSz_Vlw7s
הורה נהלל|CRtMiW9lWv0
יש לי כנרת|UvvPNZaxwAg
שיר המנון לרחובות|oOrNNIzNqjs
המנון לבאר שבע|IcQQ6ZzCxI0
בוקרי לכיש|259EMaCfR6k
אל אדמות לכיש|IOyrORrlgUM
שיר על שושנה|nRei_VXuHnY
דגניה|WD17E0bhFz8
החיטה צומחת שוב|dyMocyzWsiQ
ביתי אל מול גולן|mVRbAK2v2yQ
שיר קוצרי העמק|CPS-UbzmIK4
המגדל הראשון|ig4fi0gKTMY
גן מאיר|2d_ENKorVC0
טנגו תל אביב|SENpm0AMIJw
ליל גליל|Vzx2QxX5tfA
טנגו כפר סבא|Zf7HUhj23NM
הו, לילות ירושלים|zDJpk93SlRw
אילת|lLXGPT9WA5Q
חניתה|bpRnUHffqgY
בשערייך ירושלים|iqSXAbuOaeI
בנות תענך|o0v1JjGSoK4
תל אביב|0dfll63FRdg
בגליל העליון|SvQeb4kUjrc
שיר תל-חי|ADmiey8577A
שיר ההד|vdWndbHYmYc
ארצנו הקטנטונת|9vSVozxX9JY
על חוף אילת|WWkFXsx_6Pc
הורה נגב|-q2RbuoPwNk
בהר אפרים ביקנעם|CiBAcjvTsLw
לך ירושלים|k_A1FODbEUs
שיר לעמק|GgIZhDguegw
שיר של זייד|cQcc4MJMxgU
אח, בנה הגליל|hMvomXqlolo
שדות שבעמק|IX0dqpp7YrQ
בשדות בית לחם|T4dYPn8nipw
בכל זאת יש בה משהו|fi5y7GYYpg8
לשתיל בנגב|R3yLTJM41g8
עין גדי|gJqiowD-c9A
שיר אסירי עכו|TjpMuuNFdW8
קרב הראל|qlAoq1Y9DDM
אין כירושלים|-APUHKjdojY
אני מצפת|uD28i7f9_SA
בגן השקמים|MZ54N3U4x8A
"""
YT_LINKS="\n".join(l for l in YT_LINKS.splitlines() if l.strip() and not l.endswith('|-'))

# New songs: place|title|videoId|source|note
NEW_SONGS = """
jlm|אני עולה לירושלים|0uvJ5ua1x0U|שיר עד|
einharod|פה עין חרוד|hdlPPX0A0Nc|שיר עד|
gush|אגדת הל"ה|x-Ihy5ZVOeQ|שיר עד|שיירת הל"ה בדרך לגוש עציון
general_road|פיתולי הדרך|ABsOHPGuMaw|שיר עד|
telaviv|הולדת הנמל|u4E5Pzkftfc|שיר עד|נמל תל אביב
roshpina|מקוסטינה עד ראש פינה|c4D-Vapp-eM|שיר עד|
valley90|לילה בבקעה|tB8ReptWdPE|שיר עד|
emek|שבת בעמק|f08IoXYWxYg|שיר עד|
jlm_oldcity|שיר לכותל|oHH9j9CzhK8|שיר עד|
eilat|עוז (אל אילת)|dIdbqpdwbok|שיר עד|
safed|כאן בצפת|6rlo1KZ0qok|שיר עד|ייתכן שזה "כאן צפת"
arava_road|ערבה ערבה|mqWZyeb6l1A|שיר עד|
beersheva|במסילה לבאר שבע|BZNdJJ67I6k|שיר עד + מורשת ארץ (רכבות)|
jlm|צאינה וראינה בנות ירושלים|4AyPXrmpOdQ|שיר עד|
jlm|אני לך ואת לי (ירושלים)|ouaRnRPRp6I|שיר עד|
kinneret|רחל של הכנרת|VcDdc3WEor8|שיר עד|על רחל המשוררת
jlm_oldcity|ליד קדרון המים|2dbJi9AIgao|שיר עד|נחל קדרון
jlm|שלום ירושלים|ZgB5EvyNw8Q|שיר עד|
negev|ארץ הנגב|e1_XG_aVo_w|שיר עד|
beersheva|בת שבע|nuiLd4005K8|שיר עד + מורשת ארץ (מלחמת העצמאות)|שיר הפלמ"ח על כיבוש באר שבע
rehovot|רחובות|AKf-HJR0G7I|שיר עד|
valley90|נגן לי ירדן|43IwJGqmZzY|שיר עד + מורשת ארץ + ויקיפדיה|שיר על נהר הירדן
negev|גמלים פוסעים|kdR8j8wpmAs|שיר עד|
negev|אתן במדבר|9hapCWihlyM|שיר עד|
general|אל בורות המים|PqKkGB2D4Ck|שיר עד + ויקיפדיה|
jlm_oldcity|מול הכותל|scDBFnJ2XLs|שיר עד|
carmel|יורם (יורם ישב על הכרמל)|2_EPNxgyARI|שיר עד + זמרשת|
emek|שביל בעמק|Ne9W-8p0nEw|שיר עד|
lachish|במרחבי לכיש|VhzM_WiwaRA|שיר עד|
lachish|שיר לכיש (זמר לכיש)|uc62gw3kEH4|שיר עד|
emek|פינת העמק הקטנה|AJXSXy0qQkE|שיר עד|
degania|דגניה שלי|Nc2KCXNJLbY|שיר עד|
kinneret_lake|האם זו עדיין אותה הכנרת|DuuPtOfBkrA|שיר עד|
telaviv|שיר הילד ניסים (לילות תל אביב)|yOTggezlFe8|שיר עד + זמרשת|
eilat|מפרץ ים-סוף|PbDkjhNjEeg|שיר עד|
jlm|כאן בירושלים|YIlfFL8hLTQ|שיר עד|
eilat|אהבה באילת|CJ6zm8rZVTc|שיר עד|
emek|פה בעמק|mbWKK5FvZiA|שיר עד|
negev|בין חולות מדבר|NAPaAIOdXhA|שיר עד + זמרשת|
jlm|ירושלים ירושלים|hqCRFl5H7as|שיר עד|
valley90|שבת (חופי ירדן)|eL3OUTFi_Wg|שיר עד + ויקיפדיה|שיר על נהר הירדן
negev|בת מדבר|iZ1Dszjgr2A|שיר עד + זמרשת|
negev|אורחת גמלים|-|שיר עד + זמרשת|
kinneret_lake|הורה כינרת|5m0uq3PKe9I|שיר עד|
general_road|דרכים|1dAeJminXHM|שיר עד + זמרשת|
telaviv|תל-אביב, את עפיפון|P5UePLjgpRk|שיר עד|
jordan_valley_n|ערב בעמק הירדן|6TmbBEvLhFA|שיר עד|
sharon|שישי אדמת השרון|sjG3BuNO8Uc|שיר עד|
jlm|שבועת ירושלים|7EzdOXhyzIQ|שיר עד|
telaviv|רחוב בתל-אביב|cFRXJZPbA-Y|שיר עד|
general|שם במקום ארזים|luBuZ2xPm9I|שיר עד + ויקיפדיה|
kinneret_lake|שיר בוקר (בוקר באגם כנרת)|931L9iwZifk|שיר עד|
negev|שיר המים (שיר לנגב)|-ku_MHNuz0c|שיר עד + זמרשת|
galil|את ארץ שלי|HiLb5wWFdbk|שיר עד + זמרשת|
general|אבא אמא וארץ ישראל|-|ויקיפדיה|
general|אנחנו נשארים בארץ|-|ויקיפדיה|
general|ארץ הצבר|-|ויקיפדיה|
general|ארץ ישראל|-|ויקיפדיה|
general|יליד הארץ|-|ויקיפדיה|
general|קום והתהלך בארץ|-|ויקיפדיה|
general|תבורכי|-|ויקיפדיה|
galil|בוא איתי אל הגליל|-|ויקיפדיה + מורשת ארץ|
galil|כוכב הצפון|-|ויקיפדיה|
eilat|חורף באילת|-|ויקיפדיה|
eilat|כולם באילת|-|ויקיפדיה|
ashdod|אשדודית באליטה|-|ויקיפדיה|
beersheva|חוזרת לאותה שכונה|-|ויקיפדיה|
beersheva|שיר הקטר|-|ויקיפדיה|
batyam|מבת ים ועד הנצח|-|ויקיפדיה|
haifa|מסיבה בחיפה|-|ויקיפדיה|
yehud|Welcome to Ya Hood|-|ויקיפדיה|
jlm|אני וסימון ומואיז הקטן|-|ויקיפדיה|
jlm|השר משה מונטיפיורי|-|ויקיפדיה|
jlm|ירושלים שבלב|-|ויקיפדיה|
jlm|ירושלים שלי|-|ויקיפדיה|
jlm|ירושלם|-|ויקיפדיה|
jlm|יש עיר|-|ויקיפדיה|
jlm|עיר שלום|-|ויקיפדיה|
jlm|ציון הלא תשאלי|-|ויקיפדיה|
jlm|שישו את ירושלים|-|ויקיפדיה|
jlm|תפילה לירושלים|-|ויקיפדיה|
jlm|אלי ציון ועריה|-|ויקיפדיה|
petahtikva|פתח תקווה (אינפקציה)|-|ויקיפדיה|
rishon|מערב ראשון|-|ויקיפדיה|
telaviv|אביר על סוס לבן באמצע פלורנטין|-|ויקיפדיה|
telaviv|בחום של תל אביב|-|ויקיפדיה|
telaviv|ברחובות של תל אביב|-|ויקיפדיה|
telaviv|גרה בשינקין|-|ויקיפדיה|
telaviv|נחלת בנימין|-|ויקיפדיה|
telaviv|סמבה אבן גבירול|-|ויקיפדיה|
telaviv|תל אביב בלילה|-|ויקיפדיה|
telaviv|תל אביב זה אני ואת|-|ויקיפדיה|
kinneret_lake|נערה ושמה כנרת|-|ויקיפדיה|
allenby|גשר אלנבי|-|ויקיפדיה|
valley90|חופי ירדן|-|ויקיפדיה|שיר על נהר הירדן
"""
YW_PLACES = """
ashdod|אשדוד|עיר|השפלה|31.8|34.65|4000
batyam|בת ים|עיר|תל אביב והמרכז|32.017|34.75|2500
yehud|יהוד|עיר|תל אביב והמרכז|32.033|34.89|1800
allenby|גשר אלנבי|אתר|בקעת הירדן וצפון ים המלח|31.872|35.54|1500
"""
