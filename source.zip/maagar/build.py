import math
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.comments import Comment

F='Arial'
H_FILL=PatternFill('solid',fgColor='0D5C40'); H_FONT=Font(name=F,bold=True,color='FFFFFF')
FORM_FILL=PatternFill('solid',fgColor='EEF2EE')
EX_FONT=Font(name=F,italic=True,color='7A7A7A')
thin=Side(style='thin',color='D7DDD6')

REG={'judea':'הרי יהודה וגוש עציון','jlm':'ירושלים','valley':'בקעת הירדן וצפון ים המלח','gilboa':'עמק בית שאן והגלבוע','kinneret':'עמק הירדן והכינרת','all':'ארצי'}
REGIONS=['הרי יהודה וגוש עציון','ירושלים','הדרך לירושלים','בקעת הירדן וצפון ים המלח','ים המלח ומדבר יהודה','עמק בית שאן והגלבוע','עמק יזרעאל','עמק הירדן והכינרת','הגליל התחתון','הגליל העליון והחולה','הגליל המערבי','הגולן והחרמון','השומרון','הר חברון','חיפה והכרמל','השרון והחוף','תל אביב והמרכז','השפלה','הנגב','הערבה ואילת','ארצי']
TYPES=['עיר','יישוב','יישוב / גוש','שכונה','אתר','אתר (נחל)','צומת','קטע כביש','אזור','כללי']
from moreshet import NEW_PLACES, SONGS, EXISTING
from zemereshet import ZEM_PLACES, ZEM
from yt_wiki import YT_LINKS, NEW_SONGS, YW_PLACES
from general import GEN, GEN_PLACES
from kibbutz import KB_PLACES, KB
from wiki_refs import WIKI
from figures import FIG_PLACES, FIG
import ctx as CTXM
import landscape as LSC
from regions2 import R_PLACES, R
from user_adds import U_PLACES, U
from yt_route import YTR
from user_adds3 import U3_PLACES, U3, MOVES3, CONFIRM
from kotner import KOT_PLACES, KOT_T, KOT, KOT_ALIAS, KOT_YT
from shirad2 import SA_PLACES, SA, SA_LAND, SA_EVENTS
from yt_auto import YT_AUTO
from taharlev import TH_PLACES, TH, TH_EXISTING, TH_MOVES, TH_EXTRA, TH_YT, TH_LAND
from user_adds2 import U2_PLACES, U2, MOVES, YT_EXTRA, DIRECTION
U_IDS={l.split('|')[0] for l in (U_PLACES+U2_PLACES+U3_PLACES+TH_PLACES+KOT_PLACES+SA_PLACES).splitlines() if l.strip()}
R_IDS={l.split('|')[0] for l in R_PLACES.splitlines() if l.strip()}
FIG_IDS={l.split('|')[0] for l in FIG_PLACES.splitlines() if l.strip()}
KB_IDS={l.split('|')[0] for l in KB_PLACES.splitlines() if l.strip()}
NEW_SONGS=NEW_SONGS.strip()+'\n'+GEN.strip()
YW_IDS={l.split('|')[0] for l in YW_PLACES.splitlines() if l.strip()}
ZEM_IDS={l.split('|')[0] for l in ZEM_PLACES.splitlines() if l.strip()}
import re
NEW_PLACES="\n".join(l for l in (NEW_PLACES+ZEM_PLACES+YW_PLACES+KB_PLACES+FIG_PLACES+GEN_PLACES+R_PLACES+U_PLACES+U2_PLACES+U3_PLACES+TH_PLACES+KOT_PLACES+SA_PLACES).splitlines() if l.strip())
places=[
 ('gush','גוש עציון','יישוב / גוש',31.655,35.122,2600,'judea',''),
 ('efrat','אפרת','יישוב',31.655,35.152,1500,'judea',''),
 ('betlehem','בית לחם','עיר',31.712,35.198,2200,'judea','כדאי לשקול אזור נפרד לקבר רחל'),
 ('jlm','ירושלים','עיר',31.776,35.228,5500,'jlm','עיר גדולה: אולי לפצל לאזורים (הר הצופים, העיר העתיקה)'),
 ('arava','בית הערבה','יישוב',31.808,35.49,2800,'valley',''),
 ('jericho','יריחו','עיר',31.857,35.462,2600,'valley',''),
 ('naaran','נערן','אתר (נחל)',31.89,35.44,1600,'valley',''),
 ('gilgal','גלגל','יישוב',31.997,35.445,2200,'valley',''),
 ('valley90','כביש הבקעה','קטע כביש',32.15,35.5,None,'valley','רצועה לאורך כביש 90 מיריחו עד שדי תרומות. שיר כל כ-9 ק"מ כשאין שיר מקומי'),
 ('trumot','שדי תרומות','יישוב',32.457,35.5,2200,'gilboa','שירי הגלבוע אולי מתאימים לאזור "הגלבוע" נפרד'),
 ('beitshean','בית שאן','עיר',32.5,35.502,2600,'gilboa',''),
 ('kochav','כוכב הירדן','אתר',32.595,35.527,2200,'gilboa',''),
 ('afikim','אפיקים','יישוב',32.678,35.578,1500,'kinneret',''),
 ('tzemach','צומת צמח','צומת',32.703,35.587,550,'kinneret',''),
 ('degania','דגניה','יישוב',32.708,35.574,650,'kinneret',''),
 ('kinneret','כינרת','יישוב',32.722,35.563,900,'kinneret','המושבה כינרת (לא האגם)'),
 ('tiberias','טבריה','עיר',32.79,35.533,3500,'kinneret',''),
 ('general','שירי ארץ ישראל','כללי',None,None,None,'all','מתנגנים כשאין שיר מקומי, כל כ-18 ק"מ'),
]
W='נכתב על המקום'; M='המקום מוזכר בשיר'; A='קשר של אווירה או היסטוריה'; B='נכתב עבור המקום או במקום'
# (place, title, lyrics, music, performer, connection)
songs={
 'gush':[('שיר ההד','','','','')],
 'efrat':[('בשדמות בית לחם','','','','')],
 'betlehem':[('בשדות בית לחם','','','',''),('ראי רחל ראי','','','','')],
 'jlm':[('ציון, ציון תמתי','','','',''),('זאת ירושלים','','','',W),('מעל פסגת הר הצופים','אביגדור המאירי','','',W),('ירושלים של זהב','נעמי שמר','נעמי שמר','שולי נתן',W)],
 'arava':[('אני זוכר את בית הערבה','','','',W)],
 'jericho':[('בשערייך יריחו','','','',W),('עץ הרימון','','','','')],
 'gilgal':[('יהושע','','','',A)],
 'naaran':[('נחל נערן','','','',W)],
 'kochav':[('שיר על שושנה','','','','')],
 'trumot':[('שיר על רעי','','','',''),('בהר הגלבוע','','','',M)],
 'beitshean':[('אני הולך לבית שאן','','','',W)],
 'afikim':[('ערב מול גלעד','','','','')],
 'valley90':[(t,'','','','') for t in ['האיש מן הבקעה','שמאל הירדן','לשיר זה כמו להיות ירדן','קטפנו תמרים','תפוחים ותמרים','הימים שעוד נכונו לנו','על ענפי שיטה','אלעד ירד אל הירדן','מרדף','ארץ המרדפים','את עיניך שא מזרחה','יש לי אהוב בסיירת חרוב','אי שם בבקעה','הימים האחרים','רד אלינו לבקעה']],
 'tzemach':[('ביתי אל מול גולן','','','',''),('הכל פתוח','','','','')],
 'degania':[('דגניה','','','',W),('דגניה ב','','','',W),('הבלדה על אהרן דוד','','','',A)],
 'kinneret':[('חורשת האקליפטוס','נעמי שמר','נעמי שמר','',W),('היו לילות','','','',''),('ואולי','רחל','יהודה שרת','','')],
 'tiberias':[('טבריה','','','',W),('שם הרי גולן','','','',''),('שירי לי כינרת','','','',''),('לצפון באהבה','','','','')],
 'general':[(t,'','','','') for t in ['אומרים ישנה ארץ','סימן שעוד לא הגענו','עוד לא תמו כל פלאייך','ארץ טרופית יפה','יושב מול הנייר']],
}
songs['general'][0]=('אומרים ישנה ארץ','שאול טשרניחובסקי','','','')
ROUTE=[[31.655,35.118],[31.655,35.152],[31.69,35.176],[31.712,35.198],[31.75,35.215],[31.776,35.232],[31.792,35.3],[31.8,35.4],[31.808,35.488],[31.857,35.462],[31.89,35.44],[31.997,35.445],[32.1,35.48],[32.25,35.52],[32.4,35.52],[32.457,35.5],[32.5,35.502],[32.595,35.527],[32.678,35.578],[32.703,35.587],[32.708,35.574],[32.722,35.563],[32.79,35.533]]
def km(a,b):
    t=math.pi/180;h=math.sin((b[0]-a[0])*t/2)**2+math.cos(a[0]*t)*math.cos(b[0]*t)*math.sin((b[1]-a[1])*t/2)**2
    return 2*6371*math.asin(math.sqrt(h))
cum=[0]
for i in range(1,len(ROUTE)): cum.append(cum[-1]+km(ROUTE[i-1],ROUTE[i]))
def rk(p):
    best=(1e9,0)
    for i in range(len(ROUTE)):
        d=km(ROUTE[i],p)
        if d<best[0]: best=(d,cum[i])
    return round(best[1])

wb=Workbook()
def sheet(ws,headers,widths):
    ws.sheet_view.rightToLeft=True
    ws.append(headers)
    for c,w in zip(ws[1],widths):
        c.fill=H_FILL;c.font=H_FONT;c.alignment=Alignment(horizontal='center',vertical='center',wrap_text=True)
        ws.column_dimensions[c.column_letter].width=w
    ws.row_dimensions[1].height=32; ws.freeze_panes='A2'
def style_rows(ws,formula_cols=()):
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.font=Font(name=F); c.alignment=Alignment(vertical='top',wrap_text=True); c.border=Border(bottom=thin)
            if c.column_letter in formula_cols: c.fill=FORM_FILL

# Legend
lg=wb.active; lg.title='מקרא'; lg.sheet_view.rightToLeft=True
lines=[('מאגר פסקול הדרך',True),('',False),
('המאגר בנוי משלושה גיליונות:',True),
('מקומות: שורה לכל אזור שמקפיץ שיר (יישוב, אתר, צומת, קטע כביש). כל מקום מקבל מזהה קצר באנגלית.',False),
('שירים: שורה לכל צמד של שיר ומקום. שיר שמתאים לשני מקומות מופיע בשתי שורות.',False),
('מסלולים: פסקולים מוכנים לנסיעות. שורה לכל תחנה, לפי סדר הנסיעה.',False),
('ביצועים: שורה לכל ביצוע של שיר, עם מבצע, שנה וקישור. משמש לכפתור "ביצוע אחר" באפליקציה. "ברירת מחדל = כן" מסמן את הביצוע שמתנגן ראשון; כרגע נבחר אוטומטית: ביצוע עם קישור של אחד המבצעים המוכרים שמורשת ארץ מציינת, ואם אין, הביצוע החדש ביותר. כדאי לעבור ולבחור ידנית. "סוג": מקורי = לפני 1975, חדש = מ-1975 ואילך (לפי השנה בלבד, לבדיקה).',False),
('',False),('איך ממלאים:',True),
('תאים לבנים ממלאים ידנית. תאים אפורים מחושבים בנוסחה (שם המקום לפי המזהה), אין לשנות אותם.',False),
('בעמודות "סוג", "אזור", "סוג קשר" ו"סטטוס" בוחרים מרשימה נפתחת.',False),
('עדיפות: 1 = השיר הראשון שמתנגן כשנכנסים למקום.',False),
('שכבה (מחושב): מקומי = שיר של מקום מסוים; אזורי = שיר של אזור רחב או קטע כביש; כללי = שירי ארץ ישראל למילוי הפלייליסט כשאין שיר מקומי או אזורי.',False),
('דמות קשורה: לשירים על אישים שמזוהים עם מקום (טרומפלדור בתל חי, זייד בשייח\' אברייק). מיועד גם לשכבת ההערות בזמן הנסיעה.',False),
('תנאי הפעלה (בגיליון המקומות): מקומות שמתנגנים רק בתנאי מסוים, למשל נתב"ג רק כשהיעד הוא נמל התעופה.',False),
('קשר הדמות למקום: משפט קצר לשלט, שמסביר מה הקשר בין הדמות הקשורה לבין המקום שבו השיר מתנגן. השלט יציג: "על {דמות}, {קשר}", למשל "על יוסף טרומפלדור, שנפל כאן וקבור כאן". ערכים שמסומנים (לבדיקה) הם טיוטה.',False),
('אירוע היסטורי: האירוע שהשיר נכתב עליו או בעקבותיו (קרב, שיירה, אסון, עלייה, סיפור מקראי). האפליקציה יכולה להציג אותו ליד השיר, למשל "כאן נלחמו הל\"ה". מולא לפי רשימה ידנית, ודורש בדיקה.',False),
('סוג נוף: שדות / מטעים ופרדסים / מטעי תמרים / כרמים / מדבר / ים וחוף / יער וחורש / הרים / נהר ומים / עיר. שכבת נוף נכנסת בין השירים האזוריים לכלליים: האפליקציה בודקת את סוג השטח (לפי מפת שימושי קרקע, למשל OpenStreetMap) ומעדיפה שיר מילוי שמתאים למה שרואים מהחלון. מולא אוטומטית לפי שם השיר, הרשימה שממנה הגיע או האזור, ודורש בדיקה.',False),
('מתאים ל: הקשר של זמן, עונה או מזג אוויר (בוקר, ערב, לילה, שבת, חורף וגשם, סתיו, אביב, קיץ, עונת קציר). אפשר כמה ערכים מופרדים בפסיק. האפליקציה יודעת שעה ותאריך מהטלפון, ומזג אוויר משירות חיצוני לפי המיקום. משמש רק כשכבה משנית בבחירת שירי מילוי, ולעולם לא עוקף שיר של מקום. מולא אוטומטית לפי מילים בשם השיר ולפי תגיות העונות ושבת של זמרשת, ודורש בדיקה.',False),
('מקומות נוספים בשיר: לשירים שמונים מקומות רבים (כמו "אל יבנה הגליל"). השיר משויך לשכבה הכללית או האזורית, והאפליקציה תעדיף אותו במסלול שעובר בכמה מהמקומות שברשימה.',False),
('כיוון נסיעה: לשירים שמתאימים רק לכיוון אחד (למשל "אני עולה לירושלים"). ריק = מתאים לשני הכיוונים. רלוונטי כשהנהג הגדיר יעד.',False),
('אורך השיר: נדרש כדי שהאפליקציה תבחר שירי מילוי שמסתיימים בזמן לפני המקום הבא. עדיין ריק.',False),
('סוג הקשר "נכתב עבור המקום או במקום" (למשל שיר שנכתב לחג של קיבוץ) לא מספיק לבדו כדי להפעיל שיר. הוא מיועד להערות בזמן הנסיעה.',False),
('רדיוס במטרים: עיר גדולה 3,000-6,000, יישוב 1,500-2,500, צומת 500-800.',False),
('',False),('סטטוסים:',True),
('לבדיקה: נכנס למאגר, ממתין לאימות קרדיטים, קישורים ומיקום.',False),
('מאושר: נבדק ומוכן לאפליקציה. טיוטה: רעיון שעוד לא נבדק. נדחה: לא ייכנס.',False),
('',False),('מצב נוכחי:',True),
('השירים מהרשימה המקורית (נסיעה מגוש עציון לטבריה) מסומנים "לבדיקה".',False),
('קישורי יוטיוב ושירים נוספים נלקחו מהפלייליסט "שירי מקומות ונופים בארץ" של ערוץ "שיר עד" ביוטיוב. שירים כלליים ושירים על ערים נוספו מקטגוריות ויקיפדיה ("שירים על ארץ ישראל", "שירים על ערים בישראל", "שירים על הכנרת", "שירים על נהר הירדן").',False),
('שירים מהתווית "שירים על קיבוצים" של שירה עובדת סומנו בסוג הקשר "נכתב עבור המקום או במקום", כי רובם שירים שנכתבו בקיבוץ או עבורו ולא עליו.',False),
('שירים ומקומות שנוספו מתוך תגיות המקומות של זמרשת (zemereshet.co.il/tags.asp) מסומנים "טיוטה". כשהשיר כבר היה בטבלה, נוסף "זמרשת" לעמודת המקור. "אזור" רחב (כמו "הגליל" או "הנגב והמדבר") מתנגן כשאין שיר מקומי.',False),
('שירים ומקומות שנוספו מתוך "לכל מקום שיר" של מגזין מורשת ארץ (hamoreshet.org.il/everywhere-song) מסומנים "טיוטה". עמודת "מקור" מציינת מאיזו רשימה.',False),
('עמודת "ביצועים מוכרים" מעתיקה את המבצעים שמורשת ארץ מציינת. "מבצע מומלץ" נשאר לבחירתך.',False),
('עמודת "הערות" כוללת את ההקשר שמורשת ארץ נותנת לשיר (מלחמה, אירוע, אתר מדויק).',False),
('השיוך של שיר למקום נעשה על ידי Claude לפי האתר שמורשת ארץ ציינה או לפי שם השיר, ודורש בדיקה.',False),
('הקואורדינטות משוערות ונלקחו מגרסת האפליקציה. קרדיטים מולאו רק במקרים ודאיים, והשאר ריקים לאימות.',False),
]
for t,b in lines:
    lg.append([t]); c=lg.cell(lg.max_row,1); c.font=Font(name=F,bold=b,size=14 if t=='מאגר פסקול הדרך' else 11,color='0D5C40' if b else '000000')
lg.column_dimensions['A'].width=110

# Places
ws=wb.create_sheet('מקומות')
sheet(ws,['מזהה','שם המקום','סוג','אזור','קו רוחב','קו אורך','רדיוס (מטרים)','מספר שירים','הערות','תנאי הפעלה'],[13,20,14,26,11,11,12,10,48,30])
for p in places:
    ws.append([p[0],p[1],p[2],REG[p[6]],p[3],p[4],p[5],None,p[7] or None])
    r=ws.max_row; ws.cell(r,8).value=f"=COUNTIF('שירים'!$A:$A,A{r})"
for line in NEW_PLACES.strip().splitlines():
    pid,n,t,reg,la,lo,r=line.split('|')
    src='זמרשת' if pid in ZEM_IDS else ('ויקיפדיה' if pid in YW_IDS else ('שירה עובדת' if pid in KB_IDS else ('שירים על דמויות' if pid in FIG_IDS else ('חיפוש ממוקד לפי אזור' if pid in R_IDS else ('הצעת המשתמשת' if pid in U_IDS else 'מורשת ארץ')))))
    note='רצועה לאורך כביש 90 בערבה' if pid=='arava_road' else ('אזור רחב: מתנגן כשאין שיר מקומי' if t=='אזור' and r!='-' and int(r)>=10000 else 'קואורדינטות משוערות')
    if la=='-':
        ws.append([pid,n,t,reg,None,None,None,None,'קטגוריה כללית לפי סוג השיר (הוצע על ידי המשתמשת): '+{'general_road':'מתאים לקטעי דרך בין יישובים','general_city':'מתאים לכל עיר שאין לה שיר משלה','general_zion':'שירי אהבת ציון, רחבים יותר ממקום אחד'}.get(pid,'')])
    else:
        ws.append([pid,n,t,reg,float(la),float(lo),int(r) or None,None,note+'. נוסף מתוך '+src])
    rr=ws.max_row; ws.cell(rr,8).value=f"=COUNTIF('שירים'!$A:$A,A{rr})"
for rr in range(2,ws.max_row+1):
    if ws.cell(rr,1).value=='natbag': ws.cell(rr,10).value='רק כשהיעד שהוגדר הוא נתב"ג (נסיעה לטיסה). לא מתנגן למי שעובר לידו בכביש 1'
NP=ws.max_row
style_rows(ws,('H',))
for r in range(2,NP+1):
    for c in (5,6): ws.cell(r,c).number_format='0.000'
    ws.cell(r,7).number_format='#,##0'
ws.cell(2,5).comment=Comment('קואורדינטות משוערות. לאימות: לחיצה ימנית על המקום בגוגל מפות מעתיקה את הקואורדינטות.','Claude')
ls=wb.create_sheet('רשימות'); ls.sheet_state='hidden'
for i,v in enumerate(TYPES,1): ls.cell(i,1,v)
for i,v in enumerate(REGIONS,1): ls.cell(i,2,v)
for i,v in enumerate([W,M,A,B],1): ls.cell(i,3,v)
for i,v in enumerate(['טיוטה','לבדיקה','מאושר','נדחה'],1): ls.cell(i,4,v)
for formula,col in ((f"='רשימות'!$A$1:$A${len(TYPES)}",'C'),(f"='רשימות'!$B$1:$B${len(REGIONS)}",'D')):
    dv=DataValidation(type='list',formula1=formula,allow_blank=True); ws.add_data_validation(dv); dv.add(f'{col}2:{col}500')

pm={p[0]:p for p in places}
for line in NEW_PLACES.strip().splitlines(): pm[line.split('|')[0]]=line.split('|')
# Songs
ss=wb.create_sheet('שירים')
sheet(ss,['מזהה מקום','שם המקום','שם השיר','עדיפות','מילים','לחן','מבצע מומלץ','ביצועים מוכרים','שנה','סוג הקשר','קישור ספוטיפיי','קישור יוטיוב','מקור','סטטוס','הערות','אורך השיר (דק:שנ)','שכבה','דמות קשורה','מתאים ל (זמן, עונה, מזג אוויר)','מקומות נוספים בשיר','כיוון נסיעה','סוג נוף','אירוע היסטורי','קשר הדמות למקום','ביצועים נוספים (יוטיוב)','שנת כתיבה'],[12,18,26,8,18,16,18,30,7,22,22,22,24,11,36,12,10,18,22,40,24,18,30,30,48,10])
for pid,_n,*_ in places:
    for i,(t,ly,mu,pe,con) in enumerate(songs.get(pid,[]),1):
        ex=EXISTING.get((pid,t)); src='רשימה מקורית'+(' + מורשת ארץ ('+ex[2]+')' if ex else '')
        ss.append([pid,None,t,i,ly or None,mu or None,pe or None,ex[0] if ex else None,None,con or None,None,None,src,'לבדיקה',(ex[1] or None) if ex else None])
        r=ss.max_row; ss.cell(r,2).value=f"=IFERROR(INDEX('מקומות'!$B:$B,MATCH(A{r},'מקומות'!$A:$A,0)),\"מזהה לא קיים\")"
ORIG_END=ss.max_row
cnt={}
for r in range(2,ORIG_END+1): cnt[ss.cell(r,1).value]=cnt.get(ss.cell(r,1).value,0)+1
seen=set((ss.cell(r,1).value,ss.cell(r,3).value) for r in range(2,ORIG_END+1))
for line in SONGS.strip().splitlines():
    pid,t,perf,ctx,lst=line.split('|')
    assert pid in pm, pid
    if (pid,t) in seen: print('dup',pid,t); continue
    seen.add((pid,t)); cnt[pid]=cnt.get(pid,0)+1
    ss.append([pid,None,t,cnt[pid],None,None,None,perf or None,None,None,None,None,'מורשת ארץ ('+lst+')','טיוטה',('הקשר: '+ctx) if ctx else None])
    r=ss.max_row; ss.cell(r,2).value=f"=IFERROR(INDEX('מקומות'!$B:$B,MATCH(A{r},'מקומות'!$A:$A,0)),\"מזהה לא קיים\")"
def norm(t): return re.sub(r'[^\u05d0-\u05ea]','',t.replace('ך','כ').replace('ם','מ').replace('ן','נ').replace('ף','פ').replace('ץ','צ').replace('כנרת','כינרת'))
rows_by_title={}
for r in range(2,ss.max_row+1): rows_by_title.setdefault(norm(ss.cell(r,3).value),r)
zem_new=zem_dup=0
for line in ZEM.strip().splitlines():
    pid,t,note=line.split('|')
    assert pid in pm, pid
    k=norm(t)
    if k in rows_by_title:
        r=rows_by_title[k]; c=ss.cell(r,13)
        if 'זמרשת' not in (c.value or ''): c.value=(c.value or '')+' + זמרשת'
        if note:
            n=ss.cell(r,15); n.value=((n.value+'. ') if n.value else '')+note
        zem_dup+=1; continue
    cnt[pid]=cnt.get(pid,0)+1
    ss.append([pid,None,t,cnt[pid],None,None,None,None,None,None,None,None,'זמרשת (תגיות מקומות)','טיוטה',note or None])
    r=ss.max_row; rows_by_title[k]=r
    ss.cell(r,2).value=f"=IFERROR(INDEX('מקומות'!$B:$B,MATCH(A{r},'מקומות'!$A:$A,0)),\"מזהה לא קיים\")"
    zem_new+=1
print('zemereshet new',zem_new,'merged',zem_dup)
YT='https://www.youtube.com/watch?v='
def add_src(r,src):
    c=ss.cell(r,13)
    for part in src.split(' + '):
        if part.split(' (')[0] not in (c.value or ''): c.value=(c.value or '')+' + '+part
def strip(t): return norm(re.sub(r'\(.*?\)','',t))
links=0
for line in YT_LINKS.splitlines():
    t,vid=line.split('|'); k=strip(t)
    r=rows_by_title.get(k) or rows_by_title.get(norm(t))
    if not r: print('no match',t); continue
    if not ss.cell(r,12).value: ss.cell(r,12).value=YT+vid; links+=1
    add_src(r,'שיר עד')
yw_new=0
for line in NEW_SONGS.strip().splitlines():
    pid,t,vid,src,note=line.split('|')
    assert pid in pm, pid
    r=rows_by_title.get(norm(t)) or rows_by_title.get(strip(t))
    if r:
        if vid!='-' and not ss.cell(r,12).value: ss.cell(r,12).value=YT+vid; links+=1
        add_src(r,src); continue
    cnt[pid]=cnt.get(pid,0)+1
    ss.append([pid,None,t,cnt[pid],None,None,None,None,None,None,None,(YT+vid) if vid!='-' else None,src,'טיוטה',note or None])
    if vid!='-': links+=1
    r=ss.max_row; rows_by_title[norm(t)]=r
    ss.cell(r,2).value=f"=IFERROR(INDEX('מקומות'!$B:$B,MATCH(A{r},'מקומות'!$A:$A,0)),\"מזהה לא קיים\")"
    yw_new+=1
print('youtube/wiki new',yw_new,'links',links)
kb_new=0
for line in KB.strip().splitlines():
    pid,t,note=line.split('|'); assert pid in pm, pid
    r=rows_by_title.get(norm(t))
    if r and ss.cell(r,1).value==pid: add_src(r,'שירה עובדת'); continue
    cnt[pid]=cnt.get(pid,0)+1
    ss.append([pid,None,t,cnt[pid],None,None,None,None,None,B,None,None,'שירה עובדת (שירים על קיבוצים)','טיוטה',('הקשר ביוגרפי: לא מפעיל שיר לבדו. '+note) if note else 'הקשר ביוגרפי: לא מפעיל שיר לבדו'])
    r=ss.max_row
    ss.cell(r,2).value=f"=IFERROR(INDEX('מקומות'!$B:$B,MATCH(A{r},'מקומות'!$A:$A,0)),\"מזהה לא קיים\")"
    kb_new+=1
print('kibbutz new',kb_new)
CT={'W':W,'M':M,'A':A,'B':B}
by_pid={}
for r in range(2,ss.max_row+1): by_pid[(ss.cell(r,1).value,norm(ss.cell(r,3).value or ''))]=r
w_new=w_upd=0
for line in WIKI.strip().splitlines():
    pid,t,ly,mu,ct,note=line.split('|'); assert pid in pm, pid
    k=norm(t); r=by_pid.get((pid,k)) or by_pid.get((pid,strip(t)))
    if r is None and pid=='arava': r=by_pid.get(('arava',norm('אני זוכר את בית הערבה')))
    if r:
        if ly and not ss.cell(r,5).value: ss.cell(r,5).value=ly
        if mu and not ss.cell(r,6).value: ss.cell(r,6).value=mu
        if ct and not ss.cell(r,10).value: ss.cell(r,10).value=CT[ct]
        if note:
            n=ss.cell(r,15); n.value=((n.value+'. ') if n.value else '')+'ויקיפדיה: '+note
        add_src(r,'ויקיפדיה (ערך המקום)'); w_upd+=1; continue
    cnt[pid]=cnt.get(pid,0)+1
    ss.append([pid,None,t,cnt[pid],ly or None,mu or None,None,None,None,CT.get(ct),None,None,'ויקיפדיה (ערך המקום)','טיוטה',('ויקיפדיה: '+note) if note else None])
    r=ss.max_row; by_pid[(pid,k)]=r
    ss.cell(r,2).value=f"=IFERROR(INDEX('מקומות'!$B:$B,MATCH(A{r},'מקומות'!$A:$A,0)),\"מזהה לא קיים\")"
    w_new+=1
print('wiki refs new',w_new,'updated',w_upd)
f_new=f_upd=0
for line in FIG.strip().splitlines():
    pid,t,fig,ly,mu,src,note=line.split('|'); assert pid in pm, pid
    k=norm(t); r=by_pid.get((pid,k)) or by_pid.get((pid,strip(t)))
    if r:
        ss.cell(r,18).value=fig
        if ly and not ss.cell(r,5).value: ss.cell(r,5).value=ly
        if mu and not ss.cell(r,6).value: ss.cell(r,6).value=mu
        if src: add_src(r,src)
        if note:
            n=ss.cell(r,15); n.value=((n.value+'. ') if n.value else '')+note
        f_upd+=1; continue
    cnt[pid]=cnt.get(pid,0)+1
    ss.append([pid,None,t,cnt[pid],ly or None,mu or None,None,None,None,(B if not fig else A),None,None,src or 'שירים על דמויות','טיוטה',note or None,None,None,fig or None])
    r=ss.max_row; by_pid[(pid,k)]=r
    ss.cell(r,2).value=f"=IFERROR(INDEX('מקומות'!$B:$B,MATCH(A{r},'מקומות'!$A:$A,0)),\"מזהה לא קיים\")"
    f_new+=1
print('figures new',f_new,'updated',f_upd)
r_new=r_upd=0
for line in R.strip().splitlines():
    pid,t,ly,mu,ct,src,note,fig=line.split('|'); assert pid in pm, pid
    k=norm(t); r=by_pid.get((pid,k)) or by_pid.get((pid,strip(t)))
    if r:
        if ly and not ss.cell(r,5).value: ss.cell(r,5).value=ly
        if mu and not ss.cell(r,6).value: ss.cell(r,6).value=mu
        if ct and not ss.cell(r,10).value: ss.cell(r,10).value=CT[ct]
        if fig: ss.cell(r,18).value=fig
        add_src(r,src); r_upd+=1; continue
    cnt[pid]=cnt.get(pid,0)+1
    ss.append([pid,None,t,cnt[pid],ly or None,mu or None,None,None,None,CT.get(ct),None,None,src,'טיוטה',note or None,None,None,fig or None])
    r=ss.max_row; by_pid[(pid,k)]=r
    ss.cell(r,2).value=f"=IFERROR(INDEX('מקומות'!$B:$B,MATCH(A{r},'מקומות'!$A:$A,0)),\"מזהה לא קיים\")"
    r_new+=1
print('regions new',r_new,'updated',r_upd)
u_new=u_upd=0
for line in U.strip().splitlines():
    pid,t,perf,ct,note=line.split('|'); assert pid in pm, pid
    k=norm(t); r=by_pid.get((pid,k))
    if r:
        if perf and not ss.cell(r,8).value: ss.cell(r,8).value=perf
        add_src(r,'הצעת המשתמשת'); u_upd+=1; continue
    cnt[pid]=cnt.get(pid,0)+1
    if t=='קליפ השומרון':
        ss.append([pid,None,t,cnt[pid],'צור ארליך',None,None,perf,None,W,None,'https://www.youtube.com/watch?v=v7UpAfywzyQ','הצעת המשתמשת','טיוטה','שם השיר לפי כותרת הסרטון; הופק עבור המועצה האזורית שומרון, עיבוד: דני סיון'])
        r=ss.max_row; ss.cell(r,2).value=f"=IFERROR(INDEX('מקומות'!$B:$B,MATCH(A{r},'מקומות'!$A:$A,0)),\"מזהה לא קיים\")"; u_new+=1; continue
    if t=='סלינו על כתפינו':
        ss.append([pid,None,t,cnt[pid],'לוין קיפניס','ידידיה אדמון',None,perf,'1929',A,None,None,'הצעת המשתמשת + זמרשת','טיוטה',note])
        r=ss.max_row; ss.cell(r,2).value=f"=IFERROR(INDEX('מקומות'!$B:$B,MATCH(A{r},'מקומות'!$A:$A,0)),\"מזהה לא קיים\")"; u_new+=1; continue
    ss.append([pid,None,t,cnt[pid],'רחל' if pid=='shilo' else None,None,None,perf or None,None,CT[ct],None,None,'הצעת המשתמשת + ויקיפדיה' if pid=='shilo' else 'הצעת המשתמשת','טיוטה',note or None,None,None,'חנה אם שמואל' if pid=='shilo' else None])
    r=ss.max_row; by_pid[(pid,k)]=r
    ss.cell(r,2).value=f"=IFERROR(INDEX('מקומות'!$B:$B,MATCH(A{r},'מקומות'!$A:$A,0)),\"מזהה לא קיים\")"
    u_new+=1
print('user new',u_new,'updated',u_upd)
u2=0
for line in U2.strip().splitlines():
    pid,t,perf,ct,note,extra=line.split('|'); assert pid in pm, pid
    k=norm(t)
    if (pid,k) in by_pid: continue
    cnt[pid]=cnt.get(pid,0)+1
    ss.append([pid,None,t,cnt[pid],'חיים גורי' if t=='הנה מוטלות גופותינו' else None,None,None,perf or None,None,CT[ct],None,(YT+YT_EXTRA[t]) if t in YT_EXTRA else None,'הצעת המשתמשת','טיוטה',note or None,None,None,None,None,extra or None])
    r=ss.max_row; by_pid[(pid,k)]=r
    ss.cell(r,2).value=f"=IFERROR(INDEX('מקומות'!$B:$B,MATCH(A{r},'מקומות'!$A:$A,0)),\"מזהה לא קיים\")"; u2+=1
mv=0
for line in MOVES.strip().splitlines():
    t,pid,note=line.split('|')
    for r in range(2,ss.max_row+1):
        if ss.cell(r,3).value==t:
            ss.cell(r,1).value=pid; n=ss.cell(r,15); n.value=((n.value+'. ') if n.value else '')+note; add_src(r,'הצעת המשתמשת'); mv+=1
print('user2 new',u2,'moved',mv)
u3=0
for line in U3.strip().splitlines():
    pid,t,perf,ct,note,extra,fig,cx=line.split('|'); assert pid in pm, pid
    k=norm(t)
    if (pid,k) in by_pid: continue
    cnt[pid]=cnt.get(pid,0)+1
    ss.append([pid,None,t,cnt[pid],None,None,None,perf or None,None,CT[ct],None,None,'הצעת המשתמשת (מתוך ספר)','טיוטה',note or None,None,None,fig or None,cx or None,extra or None])
    r=ss.max_row; by_pid[(pid,k)]=r
    ss.cell(r,2).value=f"=IFERROR(INDEX('מקומות'!$B:$B,MATCH(A{r},'מקומות'!$A:$A,0)),\"מזהה לא קיים\")"; u3+=1
TSRC='יורם טהרלב, "אין כבר דרך חזרה" (הצעת המשתמשת)'
th=0
for line in [l for l in TH.splitlines() if l.strip()]:
    pid,t,perf,ct,note,extra,fig,cx=line.split('|'); assert pid in pm, pid
    k=norm(t)
    if (pid,k) in by_pid: continue
    cnt[pid]=cnt.get(pid,0)+1
    ss.append([pid,None,t,cnt[pid],'יורם טהרלב',None,None,perf or None,None,CT[ct],None,None,TSRC,'טיוטה',note or None,None,None,fig or None,cx or None,extra or None])
    r=ss.max_row; by_pid[(pid,k)]=r
    ss.cell(r,2).value=f"=IFERROR(INDEX('מקומות'!$B:$B,MATCH(A{r},'מקומות'!$A:$A,0)),\"מזהה לא קיים\")"; th+=1
for r in range(2,ss.max_row+1):
    t=ss.cell(r,3).value
    if t in TH_EXISTING:
        add_src(r,TSRC)
        if not ss.cell(r,5).value: ss.cell(r,5).value='יורם טהרלב'
        if t in TH_MOVES and ss.cell(r,1).value=='general':
            ss.cell(r,1).value=TH_MOVES[t]; n=ss.cell(r,15); n.value=((n.value+'. ') if n.value else '')+'לפי הצעת המשתמשת: שיר דרך'
        if t in TH_EXTRA: ss.cell(r,20).value=TH_EXTRA[t]
print('taharlev new',th)

KSRC='יואב קוטנר, "שיעור מולדת" (הצעת המשתמשת)'
KOT_LAND={}
def kbase(t): return norm(re.sub(r'\s*\(.*?\)','',t))
rows_by_title={}
for r in range(2,ss.max_row+1):
    t=ss.cell(r,3).value
    if t and ss.cell(r,1).value!='(דוגמה)': rows_by_title.setdefault(t,[]).append(r)
kb={}
for t in rows_by_title: kb.setdefault(kbase(t),[]).append(t)
kn=0
for title,tg in KOT:
    t=KOT_ALIAS.get(title) or (title if title in rows_by_title else (kb.get(kbase(title),[None])[0] if kbase(title) in kb else None)) or title
    ex=rows_by_title.get(t,[])
    pids=[];ctx=[];lands=[]
    for x in tg:
        kind,v=KOT_T[x]
        if kind in('p','cat'): pids.append(v)
        elif kind=='ctx': ctx.append(v)
        else: lands.append(v)
    if not pids and not ex: pids=['general_city' if 'עיר' in lands else 'general']
    tmpl=ss[ex[0]] if ex else None
    for pid in dict.fromkeys(pids):
        assert pid in pm, pid
        if (pid,norm(t)) in by_pid: continue
        cnt[pid]=cnt.get(pid,0)+1
        others=', '.join(x for x in tg if KOT_T[x][0]=='p' and KOT_T[x][1]!=pid)
        ct=(tmpl[9].value if tmpl else None) if pid not in ('general','general_road','general_zion','general_city') else A
        ss.append([pid,None,t,cnt[pid],tmpl[4].value if tmpl else None,tmpl[5].value if tmpl else None,tmpl[6].value if tmpl else None,tmpl[7].value if tmpl else None,tmpl[8].value if tmpl else None,ct,None,tmpl[11].value if tmpl else None,KSRC,'טיוטה','לפי הצעת המשתמשת: '+', '.join(tg),None,None,tmpl[17].value if tmpl else None,None,others or None])
        r=ss.max_row; by_pid[(pid,norm(t))]=r; rows_by_title.setdefault(t,[]).append(r)
        ss.cell(r,2).value=f"=IFERROR(INDEX('מקומות'!$B:$B,MATCH(A{r},'מקומות'!$A:$A,0)),\"מזהה לא קיים\")"; kn+=1
    for r in rows_by_title.get(t,[]):
        add_src(r,KSRC)
        if ctx:
            prev=[x.strip() for x in (ss.cell(r,19).value or '').split(',') if x.strip()]
            for x in ctx:
                if x not in prev: prev.append(x)
            ss.cell(r,19).value=', '.join(prev)
    for l in lands: KOT_LAND.setdefault(t,[]).append(l)
print('kotner new rows',kn)

SSRC='שיר עד (פלייליסטים: מקומות ונופים, יום העצמאות; הצעת המשתמשת)'
sa=0
for line in [l for l in SA.splitlines() if l.strip()]:
    pid,t,perf,ct,note,extra,fig,cx,lyr,mus,yr,vid=line.split('|'); assert pid in pm, pid
    k=norm(t)
    if (pid,k) in by_pid: continue
    cnt[pid]=cnt.get(pid,0)+1
    ss.append([pid,None,t,cnt[pid],lyr or None,mus or None,perf or None,perf or None,int(yr) if yr else None,CT[ct],None,YT+vid if vid else None,SSRC,'טיוטה',note or None,None,None,fig or None,cx or None,extra or None])
    r=ss.max_row; by_pid[(pid,k)]=r
    ss.cell(r,2).value=f"=IFERROR(INDEX('מקומות'!$B:$B,MATCH(A{r},'מקומות'!$A:$A,0)),\"מזהה לא קיים\")"; sa+=1
print('shirad2 new',sa)
for line in MOVES3.strip().splitlines():
    t,pid,note=line.split('|')
    for r in range(2,ss.max_row+1):
        if ss.cell(r,3).value==t and ss.cell(r,1).value in ('general','judea_hills'):
            if t=='בר כוכבא': ss.cell(r,18).value='בר כוכבא'
            ss.cell(r,1).value=pid; n=ss.cell(r,15); n.value=((n.value+'. ') if n.value else '')+note
for r in range(2,ss.max_row+1):
    t=ss.cell(r,3).value
    if t in CONFIRM: add_src(r,'הצעת המשתמשת (מתוך ספר)')
    if t=='אגדת הל"ה' and ss.cell(r,1).value=='gush': ss.cell(r,20).value='גבעת הקרב, הרי חברון'; ss.cell(r,18).value='לוחמי הל"ה'
print('user3 new',u3)
for r in range(2,ss.max_row+1):
    t=ss.cell(r,3).value
    if t in ('שמש בגבעון דום','שיר בן נון','יהושע'): ss.cell(r,18).value='יהושע בן נון'
    if t=='שיר מחנה בן שמן':
        ss.cell(r,5).value='אסתר כצנלסון-וינברג'; ss.cell(r,6).value='לחן עממי רוסי'; ss.cell(r,9).value=1930; ss.cell(r,10).value=A
        ss.cell(r,8).value='ותיקי המחנות העולים / עזריה אלון / אמנון בקר / חנה בריק'
        n=ss.cell(r,15); n.value=((n.value+'. ') if n.value else '')+'נכתב במחנה העבודה של "המחנות העולים" בבן שמן. זמרשת: https://www.zemereshet.co.il/song.asp?id=2861'
        add_src(r,'הצעת המשתמשת')
    if t=='שמאל הירדן':
        n=ss.cell(r,15); n.value=((n.value+'. ') if n.value else '')+'ידוע גם בשם "שתי גדות לירדן" (מילים: זאב ז\'בוטינסקי)'
        ss.cell(r,5).value='זאב ז\'בוטינסקי'
    if t=='הר הגלבוע' and ss.cell(r,1).value=='gilboa': ss.cell(r,18).value='שאול ויהונתן'
    if t=='הנה תמו יום קרב וערבו' and ss.cell(r,1).value=='gilboa':
        ss.cell(r,10).value=A; ss.cell(r,18).value='שאול המלך'
        n=ss.cell(r,15); n.value=((n.value+'. ') if n.value else '')+'על קרב שאול בגלבוע (לפי הצעת המשתמשת)'
    if t=='שיר בית"ר (המנון בית"ר)': ss.cell(r,5).value='זאב ז\'בוטינסקי'
    if t=='מסע לילי' and ss.cell(r,1).value=='maozhaim': ss.cell(r,5).value='אריה סיוון'
    if t=='אל השדות' and ss.cell(r,1).value=='general': ss.cell(r,5).value='נתן אלתרמן'
    if t=='שיר הרשת' and ss.cell(r,1).value=='naharayim':
        ss.cell(r,18).value='פנחס רוטנברג (הזקן מנהריים)'
        n=ss.cell(r,15); n.value=((n.value+'. ') if n.value else '')+'הזקן מנהריים הוא פנחס רוטנברג, שהקים את תחנת הכוח והגשר בנהריים'
    if t=='בדרך לתבור':
        n=ss.cell(r,15); n.value=((n.value+'. ') if n.value else '')+'ידוע גם בשם "דרך התבור"'
    if t=='נצח ישראל לא ישקר' and ss.cell(r,1).value=='zichron':
        ex=ss.cell(r,20).value or ''
        if 'עתלית' not in ex: ss.cell(r,20).value=(ex+', ' if ex else '')+'עתלית'
        n=ss.cell(r,15); n.value=((n.value+'. ') if n.value else '')+'ניל"י פעלה מתחנת הניסיונות בעתלית; לפי הצעת המשתמשת מתנגן גם בעתלית'
    if t=='שיר השיבה':
        if ss.cell(r,1).value=='kfar_etzion':
            ss.cell(r,1).value='gush'; ss.cell(r,20).value='כפר עציון, נתיב הל"ה'
            n=ss.cell(r,15); n.value=((n.value+'. ') if n.value else '')+'שיר השיבה לגוש עציון. לפי הצעת המשתמשת: גוש עציון ונתיב הל"ה'
        ss.cell(r,5).value='שאול רז'; ss.cell(r,9).value=1967; ss.cell(r,7).value='מקהלת ילדי גוש עציון'
        ss.cell(r,12).value=YT+'PPbUrnyNz7Q'
    if t=='שיבת ציון' and ss.cell(r,1).value=='gedera':
        ss.cell(r,5).value='אליקום צונזר'; ss.cell(r,6).value='אליקום צונזר'; ss.cell(r,9).value=1882
        ss.cell(r,7).value='חבורת רננים וחמישיית גלבוע'; ss.cell(r,8).value='חבורת רננים וחמישיית גלבוע / נתנאל אנטין (ביידיש)'
        ss.cell(r,12).value=YT+'g53Oux3kN0E'; ss.cell(r,10).value=A
    if t=='במחרשתי' and ss.cell(r,1).value in ('gedera','rishon'):
        ss.cell(r,5).value='אליקום צונזר / נח שפירא'; ss.cell(r,6).value='אליקום צונזר'; ss.cell(r,10).value=A
        ss.cell(r,7).value='חבורת רננים'; ss.cell(r,8).value='חבורת רננים / נתנאל אנטין (ביידיש)'
        ss.cell(r,12).value=YT+'iuuXd4H-JT4'
        if ss.cell(r,1).value=='gedera': ss.cell(r,20).value='ראשון לציון'
    if t=='דוגית נוסעת':
        n=ss.cell(r,15); n.value=((n.value+'. ') if n.value else '')+'ידוע גם בשם "דוגית שטה" (שורת הפתיחה); במאגר מורשת ארץ הופיע פעמיים, אוחד לפי הצעת המשתמשת'
    if t=='חוזרת לאותה שכונה' and ss.cell(r,1).value=='beersheva':
        ss.cell(r,10).value=W; n=ss.cell(r,15); n.value=((n.value+'. ') if n.value else '')+'זהבה בן גדלה בבאר שבע'
    if t=='עין גדי' and ss.cell(r,1).value=='eingedi':
        ex=ss.cell(r,20).value or ''
        if 'נחל ערוגות' not in ex: ss.cell(r,20).value=(ex+', ' if ex else '')+'נחל ערוגות'
    if t=='אגדות לוד': ss.cell(r,9).value=1959
    if t=='רדיו רמאללה': ss.cell(r,5).value='יעקב גלעד'; ss.cell(r,6).value='יהודה פוליקר'; ss.cell(r,9).value=1988
    if t=='למה צחקה מיכל': ss.cell(r,18).value='דוד המלך ומיכל'; ss.cell(r,5).value='נעמי שמר'; ss.cell(r,6).value='נעמי שמר'
    if t in DIRECTION:
        if t=='שלום לך ארץ נהדרת' and ss.cell(r,1).value!='natbag': continue
        ss.cell(r,21).value=DIRECTION[t]
ctxsets={tag:{norm(x) for x in getattr(CTXM,v).split('|')} for tag,v in [('חורף וגשם','WINTER'),('סתיו','AUTUMN'),('קיץ','SUMMER'),('אביב','SPRING'),('שבת','SHABBAT')]}
tagged=0
for r in range(2,ss.max_row+1):
    t=ss.cell(r,3).value or ''
    if ss.cell(r,1).value=='(דוגמה)': continue
    tt=re.sub(r'תל[ -]אביב|תל קציר|מערב ראשון','',t)
    tags=[]
    for rx,tag in CTXM.WORDS:
        if re.search(rx,tt) and tag not in tags: tags.append(tag)
    for tag,st in ctxsets.items():
        if (norm(t) in st or strip(t) in st) and tag not in tags: tags.append(tag)
    prev=[x.strip() for x in (ss.cell(r,19).value or '').split(',') if x.strip()]
    for x in tags:
        if x not in prev: prev.append(x)
    if prev: ss.cell(r,19).value=', '.join(prev); tagged+=1
print('context tagged',tagged)
lmap={}
for tag,lst in LSC.LAND.items():
    for t in lst.split('|'): lmap.setdefault(t,[]).append(tag)
for t,tag in TH_LAND.items(): lmap.setdefault(t,[]).append(tag)
for t,tag in SA_LAND.items():
    if tag and tag not in lmap.get(t,[]): lmap.setdefault(t,[]).append(tag)
for t,tags_ in KOT_LAND.items():
    for tag in tags_:
        if tag not in lmap.get(t,[]): lmap.setdefault(t,[]).append(tag)
lt=0
for r in range(2,ss.max_row+1):
    t=ss.cell(r,3).value; pid=ss.cell(r,1).value; src=ss.cell(r,13).value or ''
    if not t or pid=='(דוגמה)': continue
    tags=list(lmap.get(t,[]))
    for s,tag in LSC.BY_SOURCE:
        if s in src and tag not in tags: tags.append(tag)
    if pid in LSC.BY_PLACE and LSC.BY_PLACE[pid] not in tags: tags.append(LSC.BY_PLACE[pid])
    if tags: ss.cell(r,22).value=', '.join(tags); lt+=1
print('landscape tagged',lt)
MULTI={'אל יבנה הגליל':('הגליל, שומרון, יהודה, עתלית, בן שמן, בת שלמה, גדרה, גן שמואל, דגניה, הר טוב, ואדי חנין, זכרון יעקב, חדרה, חולדה, טנטורה, יסוד המעלה, יבנאל, כפר סבא, כפר אוריה, כנרת, מגדל, מוצא, מחניים, מסחה (כפר תבור), מרחביה, משמר הירדן, מלחמיה (מנחמיה), מטולה, נס ציונה, סג\'רה (אילניה), עין גנים, עקרון, פתח תקווה, פוריה, קסטינה (באר טוביה), קלנדיה, ראשון לציון, רחובות, רחמה, ראש פינה, שפיה, באר יעקב, ארטוף',
  'השיר מונה כ-45 מושבות ויישובים של העלייה הראשונה והשנייה. מעבר לגליל אין לו מקום אחד; מתאים כשיר מילוי בכל מסלול שעובר בכמה מהם. לפי זמרשת: נוסח ציוני לפיוט ותיק, מילים ולחן עממיים; יש שלושה לחנים. זמרשת: https://www.zemereshet.co.il/song.asp?id=1140')}
for r in range(2,ss.max_row+1):
    t=ss.cell(r,3).value
    if t in MULTI:
        ss.cell(r,20).value=MULTI[t][0]; ss.cell(r,15).value=MULTI[t][1]; ss.cell(r,10).value=M
# share links/performers between rows of the same song (multi-place songs)
lk={}
for r in range(2,ss.max_row+1):
    t=ss.cell(r,3).value
    if t and ss.cell(r,12).value and t not in lk: lk[t]=(ss.cell(r,12).value,ss.cell(r,7).value,ss.cell(r,5).value,ss.cell(r,6).value)
shared=0
for r in range(2,ss.max_row+1):
    t=ss.cell(r,3).value
    if t in lk and not ss.cell(r,12).value:
        y,p,w,m=lk[t]; ss.cell(r,12).value=y; shared+=1
        if p and not ss.cell(r,7).value: ss.cell(r,7).value=p
        if w and not ss.cell(r,5).value: ss.cell(r,5).value=w
        if m and not ss.cell(r,6).value: ss.cell(r,6).value=m
print('links shared',shared)
from events import EVENTS, ONLY
ev_n=0
for r in range(2,ss.max_row+1):
    t=ss.cell(r,3).value
    if t in EVENTS and (t not in ONLY or ss.cell(r,1).value in ONLY[t]):
        c=ss.cell(r,23); c.value=EVENTS[t]; c.font=Font(name=F); c.alignment=Alignment(vertical='top',wrap_text=True); ev_n+=1
print('events tagged',ev_n)
from figrel import FIGREL
fr=0
for r in range(2,ss.max_row+1):
    k=(ss.cell(r,18).value,ss.cell(r,1).value)
    if k in FIGREL:
        c=ss.cell(r,24); c.value=FIGREL[k]; c.font=Font(name=F); c.alignment=Alignment(vertical='top',wrap_text=True); fr+=1
print('figrel',fr)
from alt_yt import ALT_YT
ALT={}
for line in [l for l in ALT_YT.splitlines() if l.strip()]:
    t,v,p=line.split('|')[:3]; ALT.setdefault(t,[]).append((v,p))
an=0
for r in range(2,ss.max_row+1):
    t=ss.cell(r,3).value; main=str(ss.cell(r,12).value or '')
    if t in ALT:
        xs=[f'{p}: https://www.youtube.com/watch?v={v}' for v,p in ALT[t] if v not in main]
        if xs: c=ss.cell(r,25); c.value='\n'.join(xs); c.font=Font(name=F); c.alignment=Alignment(vertical='top',wrap_text=True); an+=1
print('alt perf rows',an)
from credits import VERIFIED, UNVERIFIED
CV={}
for l in VERIFIED.strip().splitlines():
    p=l.split('|'); CV.setdefault(p[0],p[1:])
CU={}
for l in UNVERIFIED.strip().splitlines():
    p=l.split('|'); CU.setdefault(p[0],p[1:])
cv=cu=0
for r in range(2,ss.max_row+1):
    t=ss.cell(r,3).value
    if t in CV:
        w,m,y,src=CV[t]; ch=False
        w='' if w.startswith(('לא ידוע','?')) else w; m='' if m.startswith(('לא ידוע','?')) else m
        if w and not ss.cell(r,5).value: ss.cell(r,5).value=w; ch=True
        if m and not ss.cell(r,6).value: ss.cell(r,6).value=m; ch=True
        if y:
            yc=26 if src=='זמרשת' else 9
            if not ss.cell(r,yc).value: ss.cell(r,yc).value=y; ch=True
        if ch: add_src(r,'מילים ולחן: '+src); cv+=1
    elif t in CU and CU[t][3]=='שירונט' and not (ss.cell(r,5).value and ss.cell(r,6).value):
        w,m,y,src=CU[t]; ch=False
        w='' if w.startswith(('לא ידוע','?')) else w; m='' if m.startswith(('לא ידוע','?')) else m
        if w and not ss.cell(r,5).value: ss.cell(r,5).value=w; ch=True
        if m and not ss.cell(r,6).value: ss.cell(r,6).value=m; ch=True
        if ch: add_src(r,'מילים ולחן: שירונט'); cv+=1
    elif t in CU and not (ss.cell(r,5).value and ss.cell(r,6).value):
        w,m,y,src=CU[t]; n=ss.cell(r,15)
        n.value=((n.value+'. ') if n.value else '')+f'לבדיקה, מילים/לחן לפי {src} (התאמה לפי שם בלבד): {w or "?"} / {m or "?"}'; cu+=1
print('credits verified',cv,'to check',cu)
from yt_scan import YT_SCAN
SC={}
for l in YT_SCAN.strip().splitlines():
    p=l.split('|'); SC[p[0]]=p[1:]
sp=sw=sr=st=0
for r in range(2,ss.max_row+1):
    t=ss.cell(r,3).value
    if t not in SC: continue
    p,w,m,rel,tm=SC[t]; n=ss.cell(r,15)
    if p and not ss.cell(r,7).value: ss.cell(r,7).value=p; n.value=((n.value+'. ') if n.value else '')+'מבצע לפי הסרטון'; sp+=1
    ch=False
    if w and not ss.cell(r,5).value: ss.cell(r,5).value=w; ch=True
    if m and not ss.cell(r,6).value: ss.cell(r,6).value=m; ch=True
    if ch: add_src(r,'מילים ולחן: תיאור הסרטון ביוטיוב'); sw+=1
    if rel and not ss.cell(r,9).value: ss.cell(r,9).value=rel; sr+=1
    if tm=='1' and n.value and 'קישור יוטיוב מחיפוש אוטומטי: לבדיקה' in n.value:
        n.value=n.value.replace('קישור יוטיוב מחיפוש אוטומטי: לבדיקה','קישור יוטיוב מחיפוש אוטומטי (שם הסרטון תואם)'); st+=1
print('scan: perf',sp,'credits',sw,'rel',sr,'links confirmed by title',st)
pf=0
for r in range(2,ss.max_row+1):
    if not ss.cell(r,7).value and ss.cell(r,8).value:
        first=str(ss.cell(r,8).value).split(' / ')[0].strip()
        if first: ss.cell(r,7).value=first; pf+=1
print('perf from known performances',pf)
import re as _re
inf=0
_pn={}
_ps=wb["מקומות"]
for rr in range(2,_ps.max_row+1): _pn[_ps.cell(rr,1).value]=_ps.cell(rr,2).value
for r in range(2,ss.max_row+1):
    pid=ss.cell(r,1).value; t=ss.cell(r,3).value
    if not pid or not t or ss.cell(r,10).value or str(pid).startswith(('general','land_')): continue
    pl=_re.sub(r'\s*\(.*?\)','',_pn.get(pid) or '').strip()
    keys=[k for k in _re.split(r'\s+ו|,\s*|\s+-\s+',pl) if len(k)>2]
    if any(k in t or k.replace('ה','',1) in t for k in keys):
        ss.cell(r,10).value=W; n=ss.cell(r,15); n.value=((n.value+'. ') if n.value else '')+'סוג הקשר הוסק משם השיר (לבדיקה)'; inf+=1
print('ct inferred from title',inf)
inf2=0
for r in range(2,ss.max_row+1):
    pid=ss.cell(r,1).value; t=ss.cell(r,3).value
    if not pid or not t or ss.cell(r,10).value or str(pid).startswith(('general','land_','(')): continue
    srcv=str(ss.cell(r,13).value or ''); why=None
    if ss.cell(r,18).value or ss.cell(r,23).value: ss.cell(r,10).value=A; why='דמות או אירוע'
    elif 'זמרשת (תגיות מקומות)' in srcv: ss.cell(r,10).value=M; why='תגית מקום בזמרשת'
    elif 'קוטנר' in srcv: ss.cell(r,10).value=M; why='שיוך מקום ברשימת קוטנר'
    if why:
        n=ss.cell(r,15); n.value=((n.value+'. ') if n.value else '')+f'סוג הקשר הוסק ({why}), לבדיקה'; inf2+=1
print('ct inferred from sources',inf2)
from answers import ANSWERS
CTM={'W':W,'M':M,'A':A}
na=0
for l in ANSWERS.strip().splitlines():
    k,apid,at,aa,anote=l.split('|')
    for r in range(2,ss.max_row+1):
        if ss.cell(r,1).value!=apid or ss.cell(r,3).value!=at: continue
        n=ss.cell(r,15); add=''
        if k=='B':
            if aa in CTM: ss.cell(r,10).value=CTM[aa]; add='סוג הקשר אושר בבדיקה'
            elif aa=='X' or (aa=='note' and 'לא קשור' in anote): ss.cell(r,10).value=None; ss.cell(r,14).value='הוסר מהמקום'; add='לא שייך למקום (בדיקה)'
        elif k=='C':
            if aa=='ok': add='הקישור אושר בבדיקה'
            elif aa=='perf': add='בבדיקה: השיר נכון, הביצוע לא טוב'
            elif aa=='no': ss.cell(r,12).value=None; add='הקישור נמחק בבדיקה (שיר אחר)'
        elif k=='A':
            add='מילים ולחן אושרו בבדיקה' if aa=='ok' else ('מילים ולחן לא נכונים (בדיקה)' if aa=='no' else '')
            if aa=='no': ss.cell(r,5).value=None; ss.cell(r,6).value=None
        if anote: add=(add+'. ' if add else '')+'הערת בדיקה: '+anote
        if add:
            n.value=((n.value+'. ') if n.value else '')+add; na+=1
print('review answers applied',na)
NS=ss.max_row
for r in range(2,NS+1):
    ss.cell(r,17).value=f"=IFERROR(IF(INDEX('מקומות'!$C:$C,MATCH(A{r},'מקומות'!$A:$A,0))=\"כללי\",\"כללי\",IF(OR(INDEX('מקומות'!$C:$C,MATCH(A{r},'מקומות'!$A:$A,0))=\"אזור\",INDEX('מקומות'!$C:$C,MATCH(A{r},'מקומות'!$A:$A,0))=\"קטע כביש\"),\"אזורי\",\"מקומי\")),\"\")"
style_rows(ss,('B','Q'))
for formula,col in ((f"='רשימות'!$C$1:$C$4",'J'),(f"='רשימות'!$D$1:$D$4",'N')):
    dv=DataValidation(type='list',formula1=formula,allow_blank=True); ss.add_data_validation(dv); dv.add(f'{col}2:{col}2000')
ss.auto_filter.ref=f'A1:Z{NS}'
# example row
ss.append(['(דוגמה)',None,'ירושלים של זהב',1,'נעמי שמר','נעמי שמר','שולי נתן','שולי נתן / עפרה חזה','1967',W,'https://open.spotify.com/track/...','https://www.youtube.com/watch?v=...','הצעת משתמש','טיוטה','שורת דוגמה לפורמט. אפשר למחוק'])
for c in ss[ss.max_row]: c.font=EX_FONT; c.alignment=Alignment(vertical='top',wrap_text=True)

# Routes
rs=wb.create_sheet('מסלולים')
sheet(rs,['מזהה מסלול','שם המסלול','סדר','מזהה מקום','שם המקום','ק"מ מהמוצא (משוער)','שירים במקום','הערות'],[12,26,7,12,18,14,11,40])
order=['gush','efrat','betlehem','jlm','arava','jericho','naaran','gilgal','valley90','trumot','beitshean','kochav','naharayim','ashdot','afikim','shaarhagolan','tzemach','degania','kinneret','kinneret_lake','tiberias']
for i,pid in enumerate(order,1):
    p=pm[pid]; k=rk([float(p[4]),float(p[5])]) if isinstance(p,list) else (rk([p[3],p[4]]) if p[3] else None)
    note={'valley90':'מיריחו עד שדי תרומות, כ-65 ק"מ','jlm':'דרך כביש 1 מזרחה','kinneret_lake':'אזור רחב: חופף לטבריה','naharayim':'נוסף מתוך מורשת ארץ','ashdot':'נוסף מתוך מורשת ארץ','shaarhagolan':'נוסף מתוך מורשת ארץ'}.get(pid)
    rs.append(['r1','גוש עציון ← טבריה',i,pid,None,k,None,note])
    r=rs.max_row
    rs.cell(r,5).value=f"=IFERROR(INDEX('מקומות'!$B:$B,MATCH(D{r},'מקומות'!$A:$A,0)),\"מזהה לא קיים\")"
    rs.cell(r,7).value=f"=COUNTIF('שירים'!$A:$A,D{r})"
style_rows(rs,('E','G'))
rs.append([]); rs.append([None,'סך הכול שירים במסלול',None,None,None,None,f'=SUM(G2:G{len(order)+1})'])
for c in rs[rs.max_row]: c.font=Font(name=F,bold=True)
# r2: Tel Aviv -> Jerusalem, Route 1 (~56 km). km = where the zone starts-ends along the road
R2=[('telaviv','0-5','יציאה מהעיר: מספיק לשיר אחד או שניים'),
    ('ayalon_hwy','0-8','רק אם יוצאים מתל אביב דרך נתיבי איילון'),
    (None,'8-11','קטע בלי שיר מקומי: מחלף שפירים, כ-2 דקות'),
    ('ramla','11-17.3','רמלה ולוד, מדרום לכביש. שירי נתב"ג לא מתנגנים כאן, כי הם מיועדים רק למי שנוסע לטיסה'),
    ('benshemen','17.3-19.7',''),
    (None,'19.7-26','קטע בלי שיר מקומי, כ-5 דקות. מועמדת: מודיעין (נראית מהכביש)'),
    ('emek_ayalon','26-34','עמק איילון, עד לטרון'),
    ('latrun','31-34',''),
    (None,'34-36','כ-2 דקות'),
    ('shaarhagai','36-39','תחילת העלייה'),
    ('judea_hills','39-48','שכבה אזורית: נווה אילן, הראל'),
    ('shoresh','40-42','מחלף שורש: "שיירה שלנו" נכתב לזכר אהרן אגסי שנפל כאן'),
    ('kiryat_yearim','42-45','קריית יערים ואבו גוש'),
    ('castel','47.8-49.8',''),
    ('mevaseret','48.5-50.5','מבשרת ציון, לפני הכניסה לירושלים'),
    ('road_to_jlm','0-56','שירי הדרך לירושלים כשכבה אזורית לכל המסלול'),
    ('jlm','50.3-56','הגעה: ירושלים מתנגנת עד סוף הנסיעה')]
start=rs.max_row+2
rs.append([])
for i,(pid,kmr,note) in enumerate(R2,1):
    rs.append(['r2','תל אביב ← ירושלים (כביש 1)',i,pid,None,kmr,None,note or None])
    r=rs.max_row
    if pid:
        rs.cell(r,5).value=f"=IFERROR(INDEX('מקומות'!$B:$B,MATCH(D{r},'מקומות'!$A:$A,0)),\"מזהה לא קיים\")"
        rs.cell(r,7).value=f"=COUNTIF('שירים'!$A:$A,D{r})"
    else:
        rs.cell(r,5).value='(קטע ריק)'
        for c in rs[r]: c.fill=PatternFill('solid',fgColor='F6E9CF')
    for c in rs[r]:
        c.font=Font(name=F); c.alignment=Alignment(vertical='top',wrap_text=True); c.border=Border(bottom=thin)
end=rs.max_row
rs.append([]); rs.append([None,'r2: סך הכול שירים בתחנות',None,None,None,None,f'=SUM(G{start}:G{end})'])
for c in rs[rs.max_row]: c.font=Font(name=F,bold=True)
rs.append([None,'r2: אורך ונדרש',None,None,None,'56 ק"מ, כ-45 דק\'',None,'כ-13 שירים ברצף. הכיוון ההפוך (ירושלים ← תל אביב) עובר באותן תחנות בסדר הפוך, אבל חלק מהשירים מתאימים רק לכיוון אחד; ראו עמודת "כיוון" בגיליון השירים'])
for c in rs[rs.max_row]: c.font=Font(name=F,bold=True)

# r3: Tel Aviv -> Haifa, coastal road (Route 2, ~84 km)
R3=[('telaviv','0-5','יציאה צפונה דרך נתיבי איילון'),('ayalon_hwy','0-3',''),
    ('herzliya','6-13',''),('ramathasharon','6.5-9','ממזרח לכביש'),('sharon','8-50','שכבה אזורית'),
    ('coastroad','8-76','שירי כביש החוף כשכבה אזורית'),('shefayim','14-17',''),(None,'17-19','כ-2 דקות'),
    ('poleg','19-23.5',''),('netanya','23.5-33',''),(None,'33-39','קטע בלי שיר מקומי, כ-4 דקות. מועמדים: בית ינאי, מכמורת, מעברת חדרה'),
    ('hadera','39-44',''),('caesarea','45-50',''),('taninim','51-55',''),('zichron','55.4-58','על הרכס ממזרח לכביש'),
    ('carmel','58-84','שכבה אזורית לאורך מורדות הכרמל'),(None,'58-69','קטע בלי שיר מקומי, כ-8 דקות. מועמדים: דור ונחשולים, חוף הבונים, עין הוד, פורדיס'),('atlit','69-72.5','מחנה המעפילים: שירי ההעפלה'),(None,'72-76','כ-3 דקות'),
    ('haifa','76-84','הגעה לחיפה')]
start=rs.max_row+2
rs.append([])
for i,(pid,kmr,note) in enumerate(R3,1):
    rs.append(['r3','תל אביב ← חיפה (כביש החוף)',i,pid,None,kmr,None,note or None])
    r=rs.max_row
    if pid:
        rs.cell(r,5).value=f"=IFERROR(INDEX('מקומות'!$B:$B,MATCH(D{r},'מקומות'!$A:$A,0)),\"מזהה לא קיים\")"
        rs.cell(r,7).value=f"=COUNTIF('שירים'!$A:$A,D{r})"
    else:
        rs.cell(r,5).value='(קטע ריק)'
        for c in rs[r]: c.fill=PatternFill('solid',fgColor='F6E9CF')
    for c in rs[r]:
        c.font=Font(name=F); c.alignment=Alignment(vertical='top',wrap_text=True); c.border=Border(bottom=thin)
end=rs.max_row
rs.append([]); rs.append([None,'r3: סך הכול שירים בתחנות',None,None,None,None,f'=SUM(G{start}:G{end})'])
for c in rs[rs.max_row]: c.font=Font(name=F,bold=True)
rs.append([None,'r3: אורך ונדרש',None,None,None,'84 ק"מ, כ-65 דק\'',None,'כ-18 שירים ברצף. בקטעים שבין המקומות מתנגנים שירי השרון, כביש החוף והכרמל, ואחריהם שירי ים וחוף ופרדסים מהשכבה הכללית'])
for c in rs[rs.max_row]: c.font=Font(name=F,bold=True)
# YouTube links from automatic search (route songs)
ytr={}
for r in range(2,ss.max_row+1):
    if ss.cell(r,3).value=='שיר ההודיה' and not ss.cell(r,12).value: ss.cell(r,12).value=YT+'afGspbn3zEQ'
    if ss.cell(r,3).value=='מי יבנה בית' and not ss.cell(r,12).value: ss.cell(r,12).value=YT+'yUOurlUP9sE'
    if ss.cell(r,3).value=='על הר גבוה' and not ss.cell(r,12).value:
        ss.cell(r,12).value=YT+'RMwKhkhdUGY'; ss.cell(r,5).value='ישעיהו מ, ט'; ss.cell(r,6).value='יוני גנוט'; ss.cell(r,9).value=2012
for line in [l for l in (YT_AUTO+YTR+TH_YT+KOT_YT).splitlines() if l.strip()]:
    t,vid,perf=line.split('|'); ytr[t]=(vid,perf)
ytr_hits=0
for r in range(2,ss.max_row+1):
    t=ss.cell(r,3).value
    if t in ytr and not ss.cell(r,12).value:
        ss.cell(r,12).value=YT+ytr[t][0]; ytr_hits+=1
        if ytr[t][1] and not ss.cell(r,7).value: ss.cell(r,7).value=ytr[t][1]
        n=ss.cell(r,15); n.value=((n.value+'. ') if n.value else '')+'קישור יוטיוב מחיפוש אוטומטי: לבדיקה'
print('route links added',ytr_hits)
st=0
for r in range(2,ss.max_row+1):
    t=ss.cell(r,3).value; n=ss.cell(r,15)
    if t in SC and SC[t][4]=='1' and n.value and 'קישור יוטיוב מחיפוש אוטומטי: לבדיקה' in n.value:
        n.value=n.value.replace('קישור יוטיוב מחיפוש אוטומטי: לבדיקה','קישור יוטיוב מחיפוש אוטומטי (שם הסרטון תואם)'); st+=1
print('auto links confirmed by video title',st)
# ---- ביצועים
ps=wb.create_sheet('ביצועים',2)
sheet(ps,['שם השיר','שם המקום (לדוגמה)','מבצע','שנה','קישור יוטיוב','קישור ספוטיפיי','סוג','ברירת מחדל','מקור','הערות'],[26,18,30,7,40,22,12,10,22,30])
song_place={}
for r in range(2,ss.max_row+1):
    t=ss.cell(r,3).value
    if t and ss.cell(r,1).value!='(דוגמה)':
        for k in (norm(t),strip(t)): song_place.setdefault(k,(t,pm.get(ss.cell(r,1).value)))
def pname(p):
    if p is None: return None
    return p[1]
seen_perf=set(); rows=[]
# 1) Shir Ad playlist: performer + year + link per recording
for line in open('perf_raw.txt',encoding='utf8'):
    line=line.strip()
    if not line: continue
    t,perf,yr,vid=line.split('|')
    k=norm(t); hit=song_place.get(k) or song_place.get(strip(t))
    if not hit: continue
    key=(hit[0],vid)
    if key in seen_perf: continue
    seen_perf.add(key)
    y=int(yr) if yr.isdigit() else None
    kind='מקורי' if (y and y<1975) else ('חדש' if y else None)
    rows.append([hit[0],pname(hit[1]),perf,y,YT+vid,None,kind,None,'שיר עד (יוטיוב)',None])
for t,(vid,perf) in ytr.items():
    hit=song_place.get(norm(t)) or song_place.get(strip(t))
    if not hit or (hit[0],vid) in seen_perf: continue
    seen_perf.add((hit[0],vid))
    rows.append([hit[0],pname(hit[1]),perf or '(לא צוין)',None,YT+vid,None,None,None,'חיפוש אוטומטי ביוטיוב','לבדיקה'])
# 2) performers named by Moreshet Eretz / user, without links
have={(r[0],norm(r[2])) for r in rows}
for r in range(2,ss.max_row+1):
    t=ss.cell(r,3).value; perfs=ss.cell(r,8).value; src=ss.cell(r,13).value or ''
    if not t or not perfs or ss.cell(r,1).value=='(דוגמה)': continue
    for p in [x.strip() for x in perfs.split('/') if x.strip()]:
        if (t,norm(p)) in have: continue
        have.add((t,norm(p)))
        rows.append([t,ss.cell(r,2).value if False else pname(pm.get(ss.cell(r,1).value)),p,None,None,None,None,None,'מורשת ארץ' if 'מורשת' in src else ('הצעת המשתמשת' if 'המשתמשת' in src else src.split(' + ')[0]),'חסר קישור'])
rows.sort(key=lambda x:(x[0],x[3] or 9999))
# default: earliest recording that has a link and is not a children/choir archive? keep simple: first linked per song, user to adjust
known={}
for r in range(2,ss.max_row+1):
    t=ss.cell(r,3).value; perfs=ss.cell(r,8).value
    if t and perfs: known.setdefault(t,set()).update(norm(p) for p in perfs.split('/') if p.strip())
bysong={}
for x in rows: bysong.setdefault(x[0],[]).append(x)
for t,lst in bysong.items():
    linked=[x for x in lst if x[4]]
    if not linked: continue
    kn=[x for x in linked if any(k and (k in norm(x[2]) or norm(x[2]) in k) for k in known.get(t,()))]
    pick=(kn and max(kn,key=lambda x:x[3] or 0)) or max(linked,key=lambda x:x[3] or 0)
    pick[7]='כן'
for x in rows: ps.append(x)
style_rows(ps,())
dv=DataValidation(type='list',formula1='"מקורי,חדש,הקלטה חיה,לא ידוע"',allow_blank=True); ps.add_data_validation(dv); dv.add('G2:G3000')
dv2=DataValidation(type='list',formula1='"כן,לא"',allow_blank=True); ps.add_data_validation(dv2); dv2.add('H2:H3000')
ps.auto_filter.ref=f'A1:J{ps.max_row}'
print('performances',len(rows),'songs',len({x[0] for x in rows}),'with link',sum(1 for x in rows if x[4]))
wb.save('maagar.xlsx')
print(NP-1,'places',NS-1,'songs')
