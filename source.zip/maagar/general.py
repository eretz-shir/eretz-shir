# General layer (שירי ארץ ישראל) and a few place songs found while sorting. place|title|videoId|source|note
GEN = """
kinneret_lake|אשמת הכנרת|WEqV20OVnB0|שיר עד|
negev|מדבר, חול גבעות|UTGO-JCV64U|שיר עד|
general_city|שכונה קטנה|9lbcYXxfluo|שיר עד|
general|בין הגלים|VXPybq_I8Xo|שיר עד|
general|לילה פלא|oSun0euZwkc|שיר עד + זמרשת|
general|פז כולה רז כולה|u80VWr40agk|שיר עד + זמרשת|
general|זמר כפרים|e2Sio1MvOxo|שיר עד|
general|ושילחתי אש|hkObMAT1B9E|שיר עד + זמרשת|
general|זמר הפלוגות|hdZpNCJTEHQ|שיר עד + זמרשת + מורשת ארץ|מורשת ארץ: ג'וערה, חניתה, כנרת
general|שיר הוותיקים|hUOh44cxcvE|שיר עד|
general|שיר השתיל|Xu4kwWRErUo|שיר עד|
general|שיר הגשם (בואו עננים)|H8uFKniQDr4|שיר עד|
general|הוי את ארץ הקדחת|myjFysHnDXk|שיר עד + זמרשת|
general|אלון רב זלזלים|Mh6OQzFyp-E|שיר עד|
general|הורה הרים|3VswfpkA6mA|שיר עד|
general|כפרי|yA9_N_A0b-4|שיר עד|
general|ארצי (הינך ארצי)|Jd72QtYKzwE|שיר עד + זמרשת|
general|אורן מול הים|xBZEJY4jO2M|שיר עד|
general|גמלת|G1P7XQknnTA|שיר עד|
negev|הורה ממטרה|W14nXjoLn_0|שיר עד + הצעת המשתמשת|לפי הצעת המשתמשת השיר עוסק בנגב
general|שיר השומר (מעל המגדל)|aIxlzdu_2Vs|שיר עד|
general|במצלתיים ובתופים|MUutn2hAl2k|שיר עד|
general|חליל נעלם|1xh8S4intL0|שיר עד|
general_road|הטיול הגדול|GBFu7fPGcIE|שיר עד|
general_road|קוראים לנו ללכת|rzd2GCr295c|שיר עד|
general_road|ילקוטי הפשלתי|Yi7HOg9EZgw|שיר עד|
general|הורה מחודשת (רב הלילה)|L63UAXiGtAc|שיר עד|
general|שיירת הרים (רון צליל)|XcpoFPWTpsc|שיר עד|
general|לכו ונבנה|CFXT1108tfc|שיר עד|
general|חולמים עלייך|devHTbcOz34|שיר עד|
general|סלע בודד|Mbm5BgSyYaQ|שיר עד|
general|שיר לחג עשור|RDTKjKtbdak|שיר עד|
general|ערב|zviPBhBaH0g|שיר עד|
general|שיר תודה (ביכורים פרי הילולים)|Po3CJ-SFf8U|שיר עד + זמרשת|
general|בוא שיר עברי|OKlDOBAz_MY|שיר עד|
general|יום פנה|GSFSvYz56eM|שיר עד|
general|ביתי בחיק הטבע|pCudpI08Vwc|שיר עד|
general|חמישים שנה|VCdlr2RM5Go|שיר עד|
general|שביל הסביונים (היינו נערים)|iJ2yBhUOx6s|שיר עד|
general|צריף קטן|CJ3aJe9Rt9Q|שיר עד|
general|שושנים וחוח|7--Es1Xoxzo|שיר עד|
general|שקיעה דרומית|Jy93FVyjCkY|שיר עד|
general|דייגים|lvGD0HNFszw|שיר עד|
general|אור חבצלות|M14Xm39steY|שיר עד|
general|מה יפים הלילות בכנען|FbDQFRJs2DQ|שיר עד + מורשת ארץ|
general|נאחז בכל משלט|3PWaJfJ8mjo|שיר עד + מורשת ארץ|
general|ניצני שלום (יצמח שלום)|y-Gm8afKF6E|שיר עד|
general|מעבר לנהר|u9_1Li4X8zI|שיר עד + זמרשת|
general|שירו השיר|RCuUHxksgqU|שיר עד|
general|מה נאוו|Ivmu7ekeFeM|שיר עד|
general|טוויסט מולדת|LCw1g4UC1dQ|שיר עד|
general|בת הרים|Mij18FG39x4|שיר עד|
general|בלילות מקדם|pk2GexJ0wts|שיר עד|
general|עם השחר|8KSdgtWk_5g|שיר עד + זמרשת|
general|זמר זמר לך|WIrrowqhMvA|שיר עד + זמרשת|
general|ארץ געגוע|MPuCJSkkeEE|שיר עד|
general|הארץ שלי|aV4DFh4XqBM|שיר עד|
general|עופי רוח|r1jzfhDcqaM|שיר עד|
general|מנגינה לי|FfBwZMv8fuk|שיר עד|
general|שיר העבודה (כחול ים המים)|KAB4JIL6VSE|שיר עד|
general|שאי לך מולדת|en0o_APvMBk|שיר עד + זמרשת|
general|ביכורים (בחלילים ובמצלתיים)|ubkBKm-jDiE|שיר עד|
general|אנשי עליה שניה|HirebYxgTxc|שיר עד + מורשת ארץ|
general_road|שיר הכביש|apZ8fXCJ-FY|שיר עד + זמרשת|
general|האיר השחר|uObhMbZnxc8|שיר עד|
general|הרועה הבודד|OVDmOMt8bjo|שיר עד|
general_road|שיר המשוטט|fYg8ywLbgOM|שיר עד|
general|שיר האדמה (גבע סלע)|y9Xw_fATNcg|שיר עד|
general|ליל רזים|X4IfhCg_F5A|שיר עד|
general|פלא כחול|_2bE8TLP8b4|שיר עד|
general|זאת ארצנו|sWFepBHJ0m4|שיר עד|
general|שיר למולדת|4o_pxx3ar3k|שיר עד + זמרשת|
general|למולדת אמא|JXnxmg7n2_E|שיר עד + זמרשת|
general|מולדתי ארץ כנען|1BpLF8Jl3C4|שיר עד + זמרשת|
general|קדרו פני השמים|-xZCrNXMfOk|שיר עד + זמרשת|
general|קול מהרים|2d2uW-VGWio|שיר עד|
general|את מולדת|MQf4CMhjOwk|שיר עד|
general|שיר אביב|NI7nBFoQbCg|שיר עד|
general|ניטשו צללים|D2jRUXpKWCY|שיר עד|
general|צריף בכרם|wlRqWKD7a14|שיר עד|
general|הגמל|v9hFf4-CEZs|שיר עד|
general|אל ארץ טובה|-|זמרשת (שירי מולדת)|
general|אל הכפר|-|זמרשת (שירי מולדת)|
general|אלי חופי אדמת מולדת|-|זמרשת (שירי מולדת)|
general|אם נשוב|-|זמרשת (שירי מולדת)|
general|אנו עולים ושרים|-|זמרשת (שירי מולדת)|
general|אנו עלייך שומרים|-|זמרשת (שירי מולדת)|
general|ארץ חמדתנו|-|זמרשת (שירי מולדת)|
general|ארץ שלי|-|זמרשת (שירי מולדת)|
general|ארצנו|-|זמרשת (שירי מולדת)|
general|את ארצנו היפה|-|זמרשת (שירי מולדת)|
general|באלפי ידיים|-|זמרשת (שירי מולדת)|
general|בארץ הצבי|-|זמרשת (שירי מולדת)|
general|בארץ ישראל|-|זמרשת (שירי מולדת)|
general|בני מולדת|-|זמרשת (שירי מולדת)|
general|הו ארץ מולדת|-|זמרשת (שירי מולדת)|
general|הוי ערש מולדת|-|זמרשת (שירי מולדת) + מורשת ארץ|
general|הורה אין דבר|-|זמרשת (שירי מולדת)|
general|הורה סחרחורת|-|זמרשת (שירי מולדת)|
general|הרוח שוטטה|-|זמרשת (שירי מולדת)|
general|השושנה|-|זמרשת (שירי מולדת)|
general|יש לנו ארץ|-|זמרשת (שירי מולדת)|
general|ישראל את חיינו|-|זמרשת (שירי מולדת)|
general|לארצי|-|זמרשת (שירי מולדת)|
general|למולדתי|-|זמרשת (שירי מולדת)|
general|מולדתי מולדתי|-|זמרשת (שירי מולדת)|
general|מכורה|-|זמרשת (שירי מולדת)|
general|מכורתי|-|זמרשת (שירי מולדת)|
general|מלאו אסמינו בר|-|זמרשת (שירי מולדת) + מורשת ארץ + ויקיפדיה|
general|עוד עומד בך טעמך|-|זמרשת (שירי מולדת)|
general|עלו לארץ אבות|-|זמרשת (שירי מולדת)|
general|קטונו מאוד|-|זמרשת (שירי מולדת)|
general|רונו גאולים|-|זמרשת (שירי מולדת)|
general|רוני אדמת מולדת|-|זמרשת (שירי מולדת)|
general|שאו ציונה נס ודגל|-|זמרשת (שירי מולדת) + מורשת ארץ|המנון ציוני
general|שיר העולים|-|זמרשת (שירי מולדת)|
general|שירה הנוער|-|זמרשת (שירי מולדת)|
general|שירת השומר|-|זמרשת (שירי מולדת)|
general|כי בא האות|-|זמרשת (שירי מולדת)|
general|כיסוד לבניין|-|זמרשת (שירי מולדת)|
general|אמא אדמה|-|מורשת ארץ (חקלאים ואדמה)|
general|ארץ שבעת המינים|-|מורשת ארץ (חקלאים ואדמה)|
general|גוונים|-|מורשת ארץ (חקלאים ואדמה)|
general|הזורעים בדמעה|-|מורשת ארץ (חקלאים ואדמה)|
general|והטיפו ההרים עסיס|-|מורשת ארץ (חקלאים ואדמה)|
general|חג אסיף|-|מורשת ארץ (חקלאים ואדמה)|
general|סוף עונת התפוזים|-|מורשת ארץ (חקלאים ואדמה)|
general|כי האדם עץ השדה|-|מורשת ארץ (חקלאים ואדמה)|
general|קילפתי תפוז|-|מורשת ארץ (חקלאים ואדמה)|
general|שדמתי|-|מורשת ארץ (חקלאים ואדמה)|
general|שיר הבוצרים|-|מורשת ארץ (חקלאים ואדמה)|
general|שירת הקציר|-|מורשת ארץ (חקלאים ואדמה)|
general|שיר השדה|-|מורשת ארץ (חקלאים ואדמה)|
general|שיר הכד|-|מורשת ארץ (חקלאים ואדמה)|
general|שיר חקלאי|-|מורשת ארץ (חקלאים ואדמה)|
general|אנו באנו ארצה|-|מורשת ארץ (עלייה והעפלה)|
general|שירו נא המשוררים|-|מורשת ארץ (עלייה והעפלה)|
general|שיבת ציון|-|מורשת ארץ (עלייה והעפלה)|
general|גבעה אחת|-|מורשת ארץ (סיורים ודרכים)|
general_road|דרך הכורכר|-|מורשת ארץ (סיורים ודרכים)|
general|הביתה|-|מורשת ארץ (סיורים ודרכים)|
general_road|טיול לילי|-|מורשת ארץ (סיורים ודרכים)|
general|לחזור הביתה|-|מורשת ארץ (סיורים ודרכים)|
general|שיר ללא שם|-|מורשת ארץ (סיורים ודרכים)|
general|שיר בבוקר בבוקר|-|מורשת ארץ (סיורים ודרכים)|
general|אם אתה בסביבה|-|מורשת ארץ (סיורים ודרכים)|
general|שיר עולה|-|מורשת ארץ (סיורים ודרכים)|
general|שיר השיירה|-|מורשת ארץ (סיורים ודרכים) + ויקיפדיה|
general|שיר ארץ|-|מורשת ארץ (אתרי זיכרון) + ויקיפדיה|
general_road|ושוב נצאה אל הדרך|-|הצעת המשתמשת|
general_road|אל הדרך שוב יצאנו|-|הצעת המשתמשת|
general_road|חדווה ושמוליק|-|הצעת המשתמשת|
general_road|בלדה לעוזב קיבוץ|-|הצעת המשתמשת|
general_road|בדרך הגדולה, ענבלים|-|מורשת ארץ (סיורים ודרכים)|
general_city|על העיר עפות יונים|-|הצעת המשתמשת|
general_city|ערב עירוני|-|הצעת המשתמשת + ויקיפדיה (שירים על תל אביב-יפו)|
"""
GEN_PLACES = """
general_road|שירי מסע ודרך|כללי|ארצי|-|-|-
general_city|שירי עיר|כללי|ארצי|-|-|-
"""
