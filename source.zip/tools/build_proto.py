import json,re,openpyxl
d=json.load(open('/home/claude/proto/data.json'))
wb=openpyxl.load_workbook('/home/claude/maagar/maagar.xlsx',data_only=True)
ws=wb['שירים']
CT={'נכתב על המקום':'W','המקום מוזכר בשיר':'M','קשר של אווירה או היסטוריה':'A'}
S={};skip={}
def vid(u):
    if not u: return ''
    m=re.search(r'(?:v=|youtu\.be/|embed/)([\w-]{11})',str(u)); return m.group(1) if m else ''
for r in ws.iter_rows(min_row=2,values_only=True):
    pid=r[0]; ct=r[9] or ''
    k=next((v for kk,v in CT.items() if ct.startswith(kk)),None)
    if ct and not k: k=None
    elif not ct: k=''
    if r[13]=='הוסר מהמקום': continue
    if not pid or k is None: skip[ct]=skip.get(ct,0)+1; continue
    y=vid(r[11])
    if not y: continue
    g=lambda i:(r[i] or '') if len(r)>i else ''
    S.setdefault(pid,[]).append([r[2],g(6),y,g(18),g(21),g(17),g(22),g(20),g(19),g(23),k,g(4),g(5),str(g(8)) if g(8) else '',str(g(25)) if g(25) else ''])
old=d['S']; d['S']=S
import sys; sys.path.insert(0,'/home/claude/maagar')
from alt_yt import ALT_YT
A={}
for l in ALT_YT.strip().splitlines():
    t,v,p=l.split('|')[:3]; A.setdefault(t,[]).append([v,p])
d['A']=A
print('places',len(S),'songs',sum(map(len,S.values())),'old',sum(map(len,old.values())),'skip',skip)
json.dump(d,open('/home/claude/proto/data.json','w'),ensure_ascii=False)

src=open('/home/claude/proto/app.src.html').read()
o=src.replace('__DATA__',json.dumps(d,ensure_ascii=False))
for f in ('index.html','ארץ-שיר.html'): open('/home/claude/proto/'+f,'w').write(o)
print('built app',len(o)//1024,'KB')
