import sys,json,re;sys.path.insert(0,'/tmp/claude-0')
import route_lib as R
d=json.load(open('/home/claude/simdata.json'))
for pid in list(d['S']):
    if pid in R.pl and R.pl[pid][2]!='כללי' or pid in('general','general_road','general_zion','general_city'):
        d['S'][pid]=[R.ent(s) for s in R.songs if s[0]==pid and R.trig(s)]
lm={'land_sea':'ים וחוף','land_orchard':'מטעים ופרדסים','land_desert':'מדבר','land_fields':'שדות','land_forest':'יער וחורש'}
for k,tag in lm.items():
    if k in d['S']: d['S'][k]=R.land(tag)
json.dump(d,open('/home/claude/simdata.json','w'),ensure_ascii=False)
h=open('/home/claude/sim2/index.html').read()
start=h.index('const D=')+len('const D=');end=h.index(";\nlet RT='r2';")
h=h[:start]+json.dumps(d,ensure_ascii=False)+h[end:]
open('/home/claude/sim2/index.html','w').write(h)
open('/tmp/claude-0/s.js','w').write(re.findall(r'<script>(.*?)</script>',h,re.S)[0])
print('sim pools',len(d['S']))
