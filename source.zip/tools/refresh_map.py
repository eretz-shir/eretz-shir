import json
from openpyxl import load_workbook
m=open('/home/claude/mapa/index.html').read()
i=m.index('const D=');j=m.index(';\nconst MB');old=json.loads(m[i+8:j]);Lold={p['id']:p.get('L') for p in old['P']}
wb=load_workbook('/home/claude/maagar/maagar.xlsx',data_only=True)
by={}
for r in wb['שירים'].iter_rows(min_row=2,values_only=True):
    if r[0] and r[0]!='(דוגמה)': by.setdefault(r[0],[]).append(r[2])
P=[];G=[]
for p in wb['מקומות'].iter_rows(min_row=2,values_only=True):
    if p[2]=='כללי': G.append({'n':p[1],'c':len(by.get(p[0],[]))});continue
    if p[4] is None: continue
    P.append({'id':p[0],'n':p[1],'t':p[2],'g':p[3],'la':p[4],'lo':p[5],'r':p[6] or 1500,'c':len(by.get(p[0],[])),'s':by.get(p[0],[]),'L':Lold.get(p[0])})
open('/home/claude/mapa/index.html','w').write(m[:i+8]+json.dumps({'P':P,'G':G},ensure_ascii=False)+m[j:])
print('map',len(P),G)
