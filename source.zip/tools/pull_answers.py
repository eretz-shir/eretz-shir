# usage: python3 pull_answers.py answers.json  -> writes /home/claude/maagar/answers.py
import json,sys
docs=json.load(open(sys.argv[1]))
lines=[]
for d in docs:
    x=d['data']
    lines.append('|'.join([x.get('k',''),x.get('pid',''),x.get('t',''),x.get('a',''),(x.get('note') or '').replace('|','/').replace('\n',' ')]))
open('/home/claude/maagar/answers.py','w').write('# Answers from the review page (k|pid|title|answer|note)\nANSWERS = """\n'+'\n'.join(sorted(lines))+'\n"""\n')
print(len(lines))
