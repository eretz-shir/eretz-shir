import json,math
from openpyxl import load_workbook
def hk(a,b):
    t=math.pi/180;h=math.sin((b[0]-a[0])*t/2)**2+math.cos(a[0]*t)*math.cos(b[0]*t)*math.sin((b[1]-a[1])*t/2)**2;return 2*6371*math.asin(math.sqrt(h))
wb=load_workbook('/home/claude/maagar/maagar.xlsx',data_only=True)
pl={r[0]:r for r in wb['מקומות'].iter_rows(min_row=2,values_only=True)}
ss=wb['שירים'];hdr=[c.value for c in ss[1]];I={h:i for i,h in enumerate(hdr)}
songs=[s for s in ss.iter_rows(min_row=2,values_only=True) if s[0] and s[0]!='(דוגמה)']
dp={}
for r in wb['ביצועים'].iter_rows(min_row=2,values_only=True):
    if r[7]=='כן' and r[0] not in dp: dp[r[0]]=(r[2] if r[2]!='(לא צוין)' else '', r[4] or '')
def ent(s):
    t=s[2];p,y=dp.get(t,('',''))
    if not p: p=(s[I['מבצע מומלץ']] or (s[I['ביצועים מוכרים']] or '').split(' / ')[0] or '')
    y=s[I['קישור יוטיוב']] or y or ''
    return {'t':t,'p':p,'y':y,'d':s[I['כיוון נסיעה']] or '','f':s[I['דמות קשורה']] or '','c':s[I['מתאים ל (זמן, עונה, מזג אוויר)']] or ''}
def trig(s): return s[I['סוג הקשר']]!='נכתב עבור המקום או במקום'
def geo(P):
    pts=[]
    for i in range(len(P)-1):
        for j in range(20):
            f=j/20;pts.append([P[i][0]+(P[i+1][0]-P[i][0])*f,P[i][1]+(P[i+1][1]-P[i][1])*f])
    pts.append(P[-1]);c=[0]
    for i in range(1,len(pts)):c.append(c[-1]+hk(pts[i-1],pts[i]))
    return pts,c
def auto_zones(P,maxr=15000,pad=0.8):
    pts,c=geo(P);out=[]
    for pid,p in pl.items():
        if p[4] is None or p[2]=='כללי' or (p[6] or 0)>maxr:continue
        r=(p[6] or 1500)/1000
        near=[c[i] for i,q in enumerate(pts) if hk(q,[p[4],p[5]])<=r+pad]
        if near: out.append([pid,round(min(near),1),round(max(near),1),2 if p[2] in('אזור','קטע כביש') else 1,1 if p[2]=='עיר' else 0])
    return sorted(out,key=lambda z:z[1]),round(c[-1],1)
def land(tag): return [ent(s) for s in songs if s[0] in('general','general_road','general_zion') and s[I['סוג נוף']] and tag in s[I['סוג נוף']]]
def save(rid,name,frm,to,P,Z,L,lands={}):
    d=json.load(open('/home/claude/simdata.json'))
    for z in Z:
        pid=z[0]
        if pid.startswith('land_') or pid=='road_to_jlm':continue
        d['S'][pid]=[ent(s) for s in songs if s[0]==pid and trig(s)]
        d['G'][pid]=[pl[pid][4],pl[pid][5],pl[pid][6] or 1500]; d['N'][pid]=pl[pid][1]
    for k,(tag,nm) in lands.items(): d['S'][k]=land(tag); d['N'][k]=nm
    d['R'][rid]={'name':name,'from':frm,'to':to,'L':L,'Z':Z,'P':P}
    json.dump(d,open('/home/claude/simdata.json','w'),ensure_ascii=False)
    for z in Z: print(z, d['N'][z[0]], len(d['S'].get(z[0],[])))
