import openpyxl,json,re,collections
wb=openpyxl.load_workbook('/home/claude/maagar/maagar.xlsx',data_only=True);ws=wb['שירים'];pl=wb['מקומות']
reg={r[0]:r[3] for r in pl.iter_rows(min_row=2,values_only=True) if r[0]}
typ={r[0]:r[2] for r in pl.iter_rows(min_row=2,values_only=True) if r[0]}
Q=[];seen=set()
for i,r in enumerate(ws.iter_rows(min_row=2,values_only=True),start=2):
    pid,pname,t=r[0],r[1],r[2]
    if not pid or not t or str(pid).startswith('(') or r[13]=='הוסר מהמקום': continue
    note=str(r[14] or ''); link=r[11] or ''
    vid=(re.search(r'(?:v=|youtu\.be/)([\w-]{11})',str(link)) or [None,''])[1]
    base=dict(t=t,p=(pname or '').split(' (')[0],pid=pid,g=reg.get(pid,''),perf=(r[6] or '').strip(),v=vid)
    gen=str(pid).startswith(('general','land_'))
    m=re.search(r'לבדיקה, מילים/לחן לפי (\S+) \(התאמה לפי שם בלבד\): ([^.]*?) / ([^.]*?)(?:\.|$)',note)
    if m and m.group(1)!='שירונט' and ('A',t) not in seen and not (r[4] and r[5]) and 'מילים ולחן' not in note.split('לבדיקה, מילים/לחן')[-1][:0]:
        seen.add(('A',t)); Q.append(dict(base,k='A',id=f'A{i}',src=m.group(1),w=m.group(2).strip(),m=m.group(3).strip()))
    if not gen and not r[9] and typ.get(pid) not in ('אזור','קטע כביש'):
        Q.append(dict(base,k='B',id=f'B{i}',cur=''))
    if vid and 'קישור יוטיוב מחיפוש אוטומטי: לבדיקה' in note and 'הקישור אושר בבדיקה' not in note and ('C',t,vid) not in seen:
        seen.add(('C',t,vid)); Q.append(dict(base,k='C',id=f'C{i}'))
print(collections.Counter(q['k'] for q in Q))
q=json.dumps(Q,ensure_ascii=False,separators=(',',':'))
b=open('/home/claude/review/body.html').read()
b=b.replace("שורות שכבר מסומנת בהן בחירה קיבלו אותה אוטומטית משם השיר. אם היא נכונה, אין צורך לגעת.","כאן נשארו רק שירים שלא הצלחתי לסווג לבד.")
b=b.replace("הקישורים האלה נמצאו בחיפוש אוטומטי ביוטיוב. פתחי את הקישור וסמני אם זה השיר הנכון, בביצוע סביר.","הקישורים האלה נמצאו בחיפוש אוטומטי, ושם הסרטון לא תואם במדויק לשם השיר. פתחי את הקישור וסמני אם זה השיר הנכון.")
b=b.replace("שמות הכותבים והמלחינים כאן נמצאו רק לפי שם השיר, ולכן הם לא מוצגים באפליקציה.","שמות הכותבים והמלחינים כאן נמצאו בזמרשת או בוויקיפדיה רק לפי שם השיר, ולא תאמו את המבצע שלנו, ולכן הם לא מוצגים באפליקציה.")
open('/home/claude/review/בדיקת-מאגר.html','w').write(open('/home/claude/review/head.html').read()+b.replace('__Q__',q.replace('</','<\\/')))
